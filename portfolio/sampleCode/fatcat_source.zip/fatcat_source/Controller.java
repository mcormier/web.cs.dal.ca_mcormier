/* Controller */

import com.apple.cocoa.foundation.*;
import com.apple.cocoa.application.*;
import com.tms.webservices.applications.DataDirectException;

import java.util.LinkedList;

public class Controller {

  // prefs

  public MyWindow mainWindow; /* IBOutlet */

  public NSTextField usernameTextField; /* IBOutlet */
  public NSSecureTextField passwordTextField; /* IBOutlet */
  public NSTextField hoursTextField; /* IBOutlet */
  public NSStepper stepper; /* IBOutlet */

  private int hoursToDownload;

  public NSTableColumn channelColumn; /* IBOutlet */
  public NSTableColumn callSignColumn; /* IBOutlet */
  public NSTableView channelTable; /* IBOutlet */


  public NSTableColumn programColumn; /* IBOutlet */
  public NSTableColumn timeColumn; /* IBOutlet */
  public NSTableView programTable; /* IBOutlet */


  public NSTableColumn selectionColumn; /* IBOutlet */
  public NSTableView selectionTable; /* IBOutlet */

  public NSTextView descriptionText; /*IBOutlet */

  private theParser data;

  private NSUserDefaults prefs;

  private LinkedList selections;

  // Dragging variables
  public static final String FAT_CAT_DRAG_TYPE = "fatCatDragType";
  private int dragged_row = -1;
  private NSTableView dragged_table = null;
  
  public Controller() {
    selections = new LinkedList();
  }


  public void awakeFromNib() {

    //--------------------------------------------------
    //  Setup default preferences
    //--------------------------------------------------
    prefs = NSUserDefaults.standardUserDefaults();

    Object[] defaultValues = { "" , "", "4"};
    Object[] defaultKeys = { "username" , "password", "hoursToDownload" };

    NSDictionary appDefaults = new NSDictionary(defaultValues,defaultKeys);

    prefs.registerDefaults( appDefaults );


    hoursToDownload = prefs.integerForKey("hoursToDownload");
    stepper.setIntValue( hoursToDownload );
    hoursTextField.setStringValue("" + stepper.intValue() );

    usernameTextField.setStringValue ( prefs.stringForKey("username") );
    passwordTextField.setStringValue ( prefs.stringForKey("password") );

    //--------------------------------------------------
    //
    //--------------------------------------------------
      // setup double click handling
    NSSelector doubleClickCallback = new NSSelector("handleProgramDoubleClick",new Class[] {} );
    programTable.setDoubleAction(doubleClickCallback);


    data = new theParser(prefs.stringForKey("username") , prefs.stringForKey("password"));
    channelTable.reloadData();
    programTable.reloadData();

    mainWindow.setConnections( channelTable, programTable, selectionTable, selections );
    
    selectionTable.registerForDraggedTypes( new NSArray(FAT_CAT_DRAG_TYPE ) );
  }


    public void handleProgramDoubleClick() {
      String selection =  "Ch: " + data.getSortedStationChannel( channelTable.selectedRow() ) + " -- " +
                          data.getTime( channelTable.selectedRow(), programTable.selectedRow() ) + " -- " +
                          data.getProgramTitle( channelTable.selectedRow(), programTable.selectedRow() );

      selections.add( selection );

      selectionTable.reloadData();
    }


//=========================================================================
// IBActions
//=========================================================================


  public void  getListings(Object sender ) { /* IBAction */
    
    try {
      data.getListings( hoursToDownload );
    } catch ( DataDirectException dde ) {
      String defaultButton = "OK";
      String alternateButton = null;
      String otherButton = null;

       NSAlertPanel.beginAlertSheet("Authentication Failed", defaultButton , alternateButton, otherButton,
              mainWindow, this, null, null, null, "Please check your username and password in the preferences ");
    }

    channelTable.reloadData();
    programTable.reloadData();

  }

  public void  stepped(Object sender ) { /* IBAction */
    hoursToDownload = stepper.intValue();
    hoursTextField.setStringValue( "" + stepper.intValue() );
    prefs.setIntegerForKey(hoursToDownload, "hoursToDownload" );

  }



  //--------------------------------------------------
  //  Table datasource methods
  //--------------------------------------------------
  public int numberOfRowsInTableView(NSTableView tableView) {

    if( data == null ) { return 0; }

    if( tableView == programTable) {
      // nothing selected
      if( channelTable.selectedRow() <  0 ) { return 0; }

      return data.getScheduleSize( channelTable.selectedRow() );

    }

    if( tableView == channelTable ) {
      return data.channelSize();
    }


    if ( tableView == selectionTable ) {
      return selections.size();
    }

    return 0;

  }

  public Object tableViewObjectValueForLocation
     (NSTableView aTableView, NSTableColumn aTableColumn, int rowIndex) {

    if( aTableColumn == callSignColumn ) {
      return data.getSortedStationCallSign( rowIndex );
    }

    if( aTableColumn == channelColumn ) {
      return data.getSortedStationChannel( rowIndex );
    }

    if ( aTableColumn == programColumn ) {
      if( channelTable.selectedRow() <  0 ) { return null; }
      return data.getProgramTitle( channelTable.selectedRow(), rowIndex );
    }

    if ( aTableColumn == timeColumn ) {
      if( channelTable.selectedRow() <  0 ) { return null; }
      return data.getTime( channelTable.selectedRow(), rowIndex );
    }

    if ( aTableColumn == selectionColumn ) {
      return selections.get( rowIndex );
    }

    return null;
  }
  //--------------------------------------------------
  //  Table delegate methods
  //--------------------------------------------------
  public  void tableViewSelectionDidChange(NSNotification aNotification) {

    if( aNotification.object() == channelTable ) {

      int position = channelTable.selectedRow();
      // ignore column clicks
      if ( position < 0 ) { return; }

      programTable.reloadData();
    }

    if ( aNotification.object() == channelTable || aNotification.object() == programTable ) {

      int position = programTable.selectedRow();
      if ( position < 0 ) { descriptionText.setString( " ");  return;}

      

      descriptionText.setString(  data.getProgramDescription( channelTable.selectedRow(), position ) );

    }
  }
  
   public void controlTextDidEndEditing(NSNotification aNotification) {


    if ( aNotification.object() == usernameTextField ) {
      prefs.setObjectForKey( usernameTextField.stringValue(), "username");
      data.setUsername( usernameTextField.stringValue() );
    }

    if ( aNotification.object() == passwordTextField ) {
      prefs.setObjectForKey( passwordTextField.stringValue(), "password");
      data.setPassword( passwordTextField.stringValue() );
    }
  
  }

  //---------------------------
  // Dragging
  //---------------------------
  public boolean tableViewAcceptDrop 
    (NSTableView tableView, NSDraggingInfo info, int row, int operation)
  {
      if ( selectionTable == tableView ) {
      
        String toMove = (String)selections.toArray()[ dragged_row ];
        selections.add( row , new String( toMove) );
        
        if ( dragged_row < row ) {
          selections.remove(dragged_row);
        }  else {
         selections.remove(dragged_row + 1);
        }

        tableView.reloadData();

        tableView.deselectRow( tableView.selectedRow() );

        int newposition;

        // Are we moving a lower row above a higher row or a higher row below a lower row??
        if( dragged_row < row ) {
           newposition = row - 1;
        }  else {
           newposition = row;
        }

        OSXUtilities.selectTableRow( tableView, newposition );


        return true;
      }
  
    return false;
  }
  
  
  public static final int BETWEEN_ROWS = 1;
  
  public int tableViewValidateDrop
    (NSTableView tableView, NSDraggingInfo info, int row, int operation)
  {

   if( tableView == selectionTable  && operation == BETWEEN_ROWS && dragged_table == selectionTable )  {
      return NSDraggingInfo.DragOperationGeneric;
    }


    return NSDraggingInfo.DragOperationNone;
  }

  
  
  public boolean tableViewWriteRowsToPasteboard
    (NSTableView tableView, NSArray rows, NSPasteboard pboard) {

    if( rows.count() > 1 ) {     // don't allow dragging with more than one row
      return false;
    }

    if ( tableView == selectionTable ) {
      // the NSArray "rows" is actually an array of the indicies dragged
      dragged_row = Integer.parseInt( rows.objectAtIndex(0).toString() );

      dragged_table = tableView;

      // declare our dragged type in the paste board
      pboard.declareTypes( new NSArray( FAT_CAT_DRAG_TYPE ) , this );

      return true; 
    }
    
    return false;
  }

//=========================================================================
// NSWindow delegate methods
//=========================================================================
 public void windowWillClose(NSNotification aNotification) {
    NSApplication.sharedApplication().terminate(null);
 }

  
}
