
/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */


import org.w3c.dom.*;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import org.apache.xpath.XPathAPI;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import javax.xml.transform.TransformerException;

import java.io.*;
import java.util.Hashtable;

import java.util.TimeZone;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import com.tms.webservices.applications.xtvd.SOAPRequest;
import com.tms.webservices.applications.DataDirectException;

/*
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

// This implementation of LookupDataSource does not use the sites collection

// This requires that we override most of the methods of the superclass
// but makes it easier to load and write the data since we modify the document object directly

public class theParser {

  public static final String defaultDataFile = "/Users/joeschmoe/Desktop/zap2it/java_parser/src/first.txt";
  public static final String webserviceURI = "http://datadirect.webservices.zap2it.com/tvlistings/xtvdService";
  
  private String username = "";
  private String password = "";

  public static final String outfile  = "/tmp/fatcat.txt";

  public static final int ELEMENT_TYPE = 1;
  public static final int ATTR_TYPE = 2;
  public static final int TEXT_TYPE = 3;
  public static final int CDATA_TYPE = 4;
  public static final int ENTITYREF_TYPE = 5;
  public static final int ENTITY_TYPE = 6;
  public static final int PROCINSTR_TYPE = 7;
  public static final int COMMENT_TYPE = 8;
  public static final int DOCUMENT_TYPE = 9;
  public static final int DOCTYPE_TYPE = 10;
  public static final int DOCFRAG_TYPE = 11;
  public static final int NOTATION_TYPE = 12;


  NodeList stations = null;
  Node[] sortedStations;

  Hashtable schedules = new Hashtable();
  Hashtable programs = new Hashtable();

  protected SimpleDateFormat sdf;
  protected Calendar start = null;
  protected Calendar end = null;

  /**
    * An instance of the {@link com.tms.webservices.applications.xtvd.SOAPRequest}
    * class that is used to make the request to the <code>webservice
    * </code> and download the <code>XTVD document</code>.
    */
  protected SOAPRequest soapRequest;


  public static Document document;

  public static void main( String args[] ) {

    //new theParser();
     // 2004-05-07T00:00:00Z == 9:00pm ( subtract 3 hours )

    System.out.println( theParser.convertZuluToLocal("2004-05-07T00:00:00Z") );
  }

  private static String convertZuluToLocal(String s) {

    SimpleDateFormat myFormat = new SimpleDateFormat( "hh:mm a" );
    myFormat.setTimeZone( TimeZone.getDefault() );

    SimpleDateFormat zulu = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss'Z'" );
    zulu.setTimeZone( TimeZone.getTimeZone( "UTC" ) );

    try {
      Date date = zulu.parse(s);
       return myFormat.format( date  );
    } catch (ParseException e) {
      e.printStackTrace();
    }


    return "Exception in convertZuluToLocal";
  }

  public theParser( String username, String password ) {
    super();

    setUsername( username );
    setPassword( password );


    System.out.println("loading data");
    loadData();

    sdf = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss'Z'" );
    sdf.setTimeZone( TimeZone.getTimeZone( "UTC" ) );




    System.out.println("done loading data");
  }
  
  public void setUsername( String user ) { username = new String( user ); }

  public void setPassword( String pass ) { password = new String( pass ); }

  private void sortStations() {
    
    int biggest = 0;
    // find the highest channel
    for (int i = 0; i < stations.getLength(); i++) {
      String id = getStationChannel(i);
      int current = Integer.parseInt( id );
      if ( current > biggest ) biggest = current; 
    }
      
    Node[] tempSortedStations = new Node[ biggest + 1];

   // Sort with spaces 
    for (int i = 0; i < stations.getLength(); i++) {
      String id = getStationChannel(i);
      int current = Integer.parseInt( id );

      tempSortedStations[ current ] = stations.item( i );
    }

    int currentPos = 0;
    sortedStations = new Node[ stations.getLength() ];

    // compact
    for (int i = 0; i < biggest + 1; i++) {
      if (  tempSortedStations[ i ] != null )  {
        sortedStations[ currentPos ] = tempSortedStations[i];
        currentPos++;
      }
    }
  }


  public void getListings( int hours ) 
         throws DataDirectException 
  {
         
    start = Calendar.getInstance();
    end = Calendar.getInstance();
    end.setTime( start.getTime() );
    end.add( Calendar.HOUR_OF_DAY, hours );

    System.out.println("Start Time --> " + sdf.format( start.getTime() ));
    System.out.println("End Time --> " + sdf.format( end.getTime() ));

    try {
      soapRequest = new SOAPRequest( username, password, webserviceURI );
      soapRequest.getData( start, end, new PrintWriter( System.out ) );
      soapRequest.getDataFile( start, end, outfile );
    } catch ( DataDirectException dde ) {
      dde.printStackTrace();
      throw dde;
    }
    catch (Exception e) {
      e.printStackTrace();
    }

    loadData();
  }




  protected void loadData() {
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    DocumentBuilder builder = null;

    try {
      builder = factory.newDocumentBuilder();
    } catch (ParserConfigurationException e) {
      e.printStackTrace();
    }

    try {
      builder.setErrorHandler(
              new org.xml.sax.ErrorHandler() {
                // ignore fatal errors (an exception is guaranteed)
                public void fatalError(SAXParseException exception)
                throws SAXException {

                }
                // treat validation errors as fatal
                public void error(SAXParseException e)
                throws SAXParseException {
                  throw e;
                }
                // dump warnings too
                public void warning(SAXParseException err)
                throws SAXParseException {
                   System.out.println("** Warning"
                      + ", line " + err.getLineNumber()
                      + ", uri " + err.getSystemId() );
                   System.out.println("  " + err.getMessage() );
                }
              }

      );

      document = builder.parse( new File(outfile) );
      // clear caches
      schedules = new Hashtable();
      programs = new Hashtable();
      System.gc();

     } catch ( Exception fce ) {
       System.out.println("????");
       return;
     }
    

    try {
      stations = XPathAPI.selectNodeList(document,"//station" );

    } catch (TransformerException e) {
      e.printStackTrace();
    }

    sortStations();

  }




   public String getTime( int station, int index ) {
    String stationId = getSortedStationID( station );
    NodeList list =getScheduleListForStation( stationId );


    Node theRightOne = list.item( index );
    
    if( theRightOne == null ) { return "null Node"; }
    
    NamedNodeMap attr = theRightOne.getAttributes();
    
    if( attr == null ) { return "null attr"; }
    
    Node program = attr.getNamedItem("time");

    return  convertZuluToLocal( program.getFirstChild().getNodeValue() );
  }


  public String getProgramTitle( int station, int index ) {
    String stationId = getSortedStationID( station );
    NodeList list = getScheduleListForStation( stationId );


    Node theRightOne = list.item( index );
    
    if( theRightOne == null ) { return "null Node"; }
    
    NamedNodeMap attr = theRightOne.getAttributes();
    Node program = attr.getNamedItem("program");

    Node node = getProgram( program.getFirstChild().getNodeValue() );

    list = node.getChildNodes();
    for (int i = 0; i < list.getLength(); i++) {
      Node temp = list.item(i);
      if( temp.getNodeName().equalsIgnoreCase("title" ) ) {
        return temp.getFirstChild().getNodeValue();
      }

    }

    return null;
  }

   public String getProgramDescription( int station, int index ) {
    String stationId = getSortedStationID( station );
    NodeList list = getScheduleListForStation( stationId );


    Node theRightOne = list.item( index );
    NamedNodeMap attr = theRightOne.getAttributes();
    Node program = attr.getNamedItem("program");

    Node node = getProgram( program.getFirstChild().getNodeValue() );

    String description = "";
    String subtitle = "";
    String syndicatedEpisodeNumber = "";

    list = node.getChildNodes();
    for (int i = 0; i < list.getLength(); i++) {
      Node temp = list.item(i);
      if( temp.getNodeName().equalsIgnoreCase("description" ) ) {
        description = temp.getFirstChild().getNodeValue();
      }

     if( temp.getNodeName().equalsIgnoreCase("subtitle" ) ) {
        subtitle = temp.getFirstChild().getNodeValue();
      }
     if( temp.getNodeName().equalsIgnoreCase("syndicatedEpisodeNumber" ) ) {
        syndicatedEpisodeNumber =  temp.getFirstChild().getNodeValue();
      }


    }

    return "Subtitle: "  + subtitle + "\n"  +
           "Episode Number: " + syndicatedEpisodeNumber + "\n" +
           "Description : " + description;
  }


  public Node getProgram( String programId ) {

    Object program = programs.get( programId );

    if( program == null ) {
      String xpath = "//program[@id='"+ programId +"']";


      try {
        Node node = null;
        node = XPathAPI.selectSingleNode(document, xpath );
        programs.put( programId, node  );
        return node;

      } catch (TransformerException e) {
        e.printStackTrace();
      }

    }


    return (Node) program;
  }


 private NodeList getScheduleListForStation( String station ) {
    NodeList list = null;

    Object scheduleCache = schedules.get( station );

    if( scheduleCache == null ) {

      String xpath = "//schedule[@station='"+ station +"']";

      try {
        list = XPathAPI.selectNodeList( document, xpath );
      } catch (TransformerException e) {
        e.printStackTrace();
        return null;
      }

      schedules.put( station, list );
      return list;
    }

    return (NodeList)scheduleCache;

 }

 public int getScheduleSize( int station ) {
    if( document != null ) {
      String stationId = getSortedStationID( station );
      NodeList list =getScheduleListForStation( stationId );

      return  list.getLength();
    }

    return 0;
  }



  public String getStationCallSign(int index) {

    Node  node = null;


    try {
      node = XPathAPI.selectSingleNode( stations.item( index ) ,"name" );
    } catch (TransformerException e) {
      e.printStackTrace();
    }

    if( node == null ) {
      return null;
    }

    return node.getFirstChild().getNodeValue();

  }

  public String getSortedStationCallSign(int index) {

    Node  node = null;


    try {
      node = XPathAPI.selectSingleNode( sortedStations[ index ] ,"name" );
    } catch (TransformerException e) {
      e.printStackTrace();
    }

    if( node == null ) {
      return null;
    }

    return node.getFirstChild().getNodeValue();

  }

  public int channelSize() {
    if( document != null ) {
      return stations.getLength();
    }

    return 0;
  }


  public String getStationChannel( int index ) {

    Node node = stations.item( index );

    NamedNodeMap attr  = node.getAttributes();

    Node id = attr.getNamedItem( "id" );
    String idValue  = id.getFirstChild().getNodeValue();

    // Get the map element where station=id
    String xpath = "//map[@station='"+ idValue +"']";
    Node map = null;
    try {
      map = XPathAPI.selectSingleNode(document, xpath );

    } catch (TransformerException e) {
      e.printStackTrace();
    }

    attr = map.getAttributes();
    Node channel = attr.getNamedItem("channel");

    return channel.getFirstChild().getNodeValue() ;

  }


  public String getSortedStationChannel( int index ) {
    String idValue = getSortedStationID( index );

    // Get the map element where station=id
    String xpath = "//map[@station='"+ idValue +"']";
    Node map = null;
    try {
      map = XPathAPI.selectSingleNode(document, xpath );

    } catch (TransformerException e) {
      e.printStackTrace();
    }

    if( map == null ) return "";

    NamedNodeMap attr = map.getAttributes();
    Node channel = attr.getNamedItem("channel");

    return channel.getFirstChild().getNodeValue() ;

  }



  public String getSortedStationID( int index ) {
    // Node node = stations.item( index );
    Node node = sortedStations[ index ];
    if( node == null ) return "";
    
    NamedNodeMap attr  = node.getAttributes();

    Node id = attr.getNamedItem( "id" );
    return id.getFirstChild().getNodeValue();

  }


}
