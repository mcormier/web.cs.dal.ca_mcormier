/* MyWindow */

import com.apple.cocoa.foundation.*;
import com.apple.cocoa.application.*;
import java.util.LinkedList;

public class MyWindow extends NSWindow {
  NSTableView channelTable;
  NSTableView progTable;
  NSTableView selectionTable;
  LinkedList selections;
  
  public MyWindow() {
    super();
  }

 public MyWindow (NSRect contentRect, int styleMask, int backingType, boolean defer) {
   super( contentRect,  styleMask,  backingType,  defer);
 }

  public static final int LEFT_ARROW = 123;
  public static final int RIGHT_ARROW = 124;
  public static final int DELETE_KEY = 51;
  
  public boolean connectionsSet = false;

  public void setConnections( NSTableView categoryTable, NSTableView bookmarkTable, NSTableView selTable, LinkedList selects ) {
    channelTable = categoryTable;
    progTable = bookmarkTable;
    selectionTable = selTable;
    selections = selects;
    
    // avoid null pointer exceptions
    connectionsSet = true;
  }


  public void keyDown(NSEvent event) {
    boolean doSuperCall = true;
    //super.keyDown(event);
    
    // avoid null pointer exceptions
    if ( !connectionsSet ) return;
    

    if ( event.keyCode() == LEFT_ARROW && this.firstResponder() == progTable ) {
      this.makeFirstResponder( channelTable );
      doSuperCall = false;
    } else

    if ( event.keyCode() == RIGHT_ARROW && this.firstResponder() == channelTable) {
      this.makeFirstResponder( progTable );
      doSuperCall = false;
      if ( progTable.selectedRow() < 0 ) {
        OSXUtilities.selectTableRow( progTable, 0);
      }
    }
    
    if (  event.keyCode() == DELETE_KEY && this.firstResponder() == selectionTable ) {
      int selected = selectionTable.selectedRow();

      if ( selected < 0 ) return;
      selections.remove( selected );
      selectionTable.reloadData();
      doSuperCall = false;
    }

    if( doSuperCall ) super.keyDown(event);

  }


}
