/*
 *  ScrollContainer.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Thu Jul 31 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
import java.awt.*;
import java.util.*;

import java.io.*;

public class ScrollContainer 
             implements Serializable
{
    private Vector     _items;
    
    public static int NAV_ARROW_HEIGHT = 20;
   
    // Distance in pixels between drawn objects
    public static int BORDER = 5;

    // How many objects to display at one time
    // before displaying up and down arrows
    private int _range = 3;
   
    // The position in the vector of the first
    // object to draw
    private int _topObjNum = 0;

    private boolean _drawBotArrow = false;
    private boolean _drawTopArrow = false;

    private int _objWidth = 0;
    private int _objHeight = 0;
    
    private Point _botArrowTopLeftCorner;
    private Point _topArrowBotLeftCorner;
    private Point _startPoint;
  
    private boolean _isVisible;
  
//---------------------------------------------------------------
// Public Methods
//---------------------------------------------------------------   
    
    //------------------------------------------------------------
    // Assumes vectorToDraw contains objects that implement the 
    // ScrollContainterObject interface and all objects in this 
    // vector have the same width and height
    //------------------------------------------------------------
    public ScrollContainer( Vector vectorToDraw ) 
    {
        _items  = vectorToDraw;
        
        _setObjWidthHeight();
        
        _isVisible = true;
    }

    public void setTopObjNum(int value) { _topObjNum = value; }

    public void setRange(int value) 
    { 
        if( value > 0)
            _range = value; 
    }

    public void paint( Graphics g, int x, int y )
    {
        if(!_isVisible) return;
    
        // Empty vector nothing to paint
        if ( _numberOfItems() == 0 ) return; 
    
        // Make sure object width and Height are set
        _setObjWidthHeight();
    
        _startPoint = new Point(x, y);
    
    
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);



        //
        // Calculate Y position
        //
        if( _numberOfItems() < _range )
        {
            y -= ( _objHeight / 2) * _numberOfItems() + (BORDER * (_numberOfItems() - 1) );
        }
        else
        {
            y -= ( _objHeight / 2) * _range + (BORDER * (_range - 1) );
        }
         

         
        //
        // Draw Objects
        //
        ScrollContainerObject tempObj;        
        int botObjNum = _topObjNum + _range - 1;

        for(int i = 0; i < _numberOfItems(); i++)
        {
            tempObj = (ScrollContainerObject)_items.elementAt(i);
            
            if( i >= _topObjNum && i <= botObjNum )
            {
                tempObj.paint(g, x, y );
                
                y += _objHeight + BORDER;
                
                tempObj.setVisible(true);
            }
            else
            {
                tempObj.setVisible(false);
            }
            
        }


        // Draw a bottom arrow
        if( botObjNum < ( _numberOfItems() - 1 ) )
        {
            _drawBotArrow = true;
            _paintBotArrow(g2, x, y);
        }
        else
            _drawBotArrow = false;


        // Draw Top arrow
        if( _topObjNum > 0 )
        {
            _drawTopArrow = true;
            
            
            int halfRange = _range/2;
            _paintTopArrow(g2,  _startPoint.x ,  
                           _startPoint.y - ( (( _objHeight * _range)/2) + (BORDER * _range ) )  );
        }
        else
            _drawTopArrow = false;


    }



    public void navArrowClicked( int checkX, int checkY )
    {
        if(!_isVisible) return;        
                
        if ( _drawBotArrow)
        {
            int y = _botArrowTopLeftCorner.y;
            int x = _botArrowTopLeftCorner.x;
            
            if( checkX >= x && checkX <= ( x + _objWidth) && checkY >= y && checkY <= ( y + NAV_ARROW_HEIGHT) )
            {
                //Bottom arrow was clicked
                _topObjNum++;
                
                dataManager.getDataManager().notifyViews();
                
                return;
            }

            
        }
        
        if ( _drawTopArrow )
        {
            int x = _topArrowBotLeftCorner.x;
            int y = _topArrowBotLeftCorner.y - NAV_ARROW_HEIGHT;
            
            if( checkX >= x && checkX <= ( x + _objWidth) && checkY >= y && checkY <= ( y + NAV_ARROW_HEIGHT) )
            {
                // Top arrow was clicked
                _topObjNum--;

                dataManager.getDataManager().notifyViews();
                
                return;
            }
        }
    }


    public void setVisible(boolean state)
    {
        _isVisible = state;
        
        //set all contained objects to not visible
        if( !_isVisible)
        {
            ScrollContainerObject tempObj;
        
            for(int i = 0; i < _numberOfItems(); i++)
            {
                tempObj = (ScrollContainerObject)_items.elementAt(i);
                
                tempObj.setVisible(false);
            }
        
        }
    }

//---------------------------------------------------------------
// Private Methods
//---------------------------------------------------------------
 
    
    private int _numberOfItems()
    {
        if( _items == null)
            return 0;
      
        return _items.size(); 
    }


    //----------------------------------------------------------------
    // Pops the first element off the vector and sets width and height
    // to the size of that object
    //----------------------------------------------------------------
    private void _setObjWidthHeight()
    {
        //Try to set obj width and height
        if( _numberOfItems() > 0 )
        {
            ScrollContainerObject tempObj = (ScrollContainerObject)_items.elementAt(0);
        
            _objWidth  = tempObj.getWidth();
            _objHeight = tempObj.getHeight();
        }
    }



    //----------------------------------------------------------------
    // Paints the bottom Arrow - Called by paint 
    //----------------------------------------------------------------
    private void _paintBotArrow(Graphics2D g, int x, int y)
    {
        _botArrowTopLeftCorner = new Point(x, y);
    
        // Create Triangle Polygon
        int[]  xPoints = new int[3];
        int[]  yPoints = new int[3];
        
        xPoints[0] = x;
        yPoints[0] = y;
        
        xPoints[1] = x + _objWidth;
        yPoints[1] = y;
        
        xPoints[2] = x + (_objWidth / 2 );
        yPoints[2] = y + NAV_ARROW_HEIGHT;

        // Paint Triangle
        g.setColor( java.awt.Color.black ); 
        g.fillPolygon( xPoints, yPoints, 3);
    }
    
    
    
    
    //----------------------------------------------------------------
    // Paints the top Arrow - Called by paint 
    //----------------------------------------------------------------
    private void _paintTopArrow( Graphics2D g, int x, int y)
    {          
        _topArrowBotLeftCorner = new Point(x,y);  
        
        // Create Triangle Polygon
        int[]  xPoints = new int[3];
        int[]  yPoints = new int[3];
        
        xPoints[0] = x;
        yPoints[0] = y;
        
        xPoints[1] = x + _objWidth;
        yPoints[1] = y;
        
        xPoints[2] = x + (_objWidth/2);
        yPoints[2] = y - NAV_ARROW_HEIGHT;
      
        // Paint Triangle
        g.setColor( java.awt.Color.black ); 
        g.fillPolygon( xPoints, yPoints, 3);
    }




}
