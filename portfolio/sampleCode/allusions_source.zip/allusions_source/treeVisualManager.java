/**
*  treeVisualManager.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Mon May 19 2003.
*
*
* @deprecated 	This class has been renamed to TreeView
*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JTree;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.util.*;

public class treeVisualManager extends visualManager
                               implements TreeExpansionListener
{
    private dataManager theData;
    private allusionWorkSpacePanel theDisplay;

    private JButton testButton;
    private JTree   dataTree;

    public treeVisualManager( dataManager theDataManager, allusionWorkSpacePanel display )
    {
        theData = theDataManager;
        theDisplay = display;

        testButton = new JButton("Test");
        
        testButton.setLocation(new java.awt.Point(10, 140));
        testButton.setVisible(true);
        testButton.setText("test");
        testButton.setSize(new java.awt.Dimension(70, 23));
        
        
    }

    public void treeExpanded( TreeExpansionEvent e)
    {
        TreePath thePath = e.getPath();
                
        DefaultMutableTreeNode tempNode = (DefaultMutableTreeNode)thePath.getPathComponent( thePath.getPathCount() - 1 );
        
        Enumeration childNodes = tempNode.children();
        
        while(childNodes.hasMoreElements() )
        {
           DefaultMutableTreeNode childNode = (DefaultMutableTreeNode)childNodes.nextElement();
           dataObject tempObject = (dataObject)childNode.getUserObject();
           
           if(tempObject.getOutLinkNumber() > 0 )
           {
                buildBranches(tempObject, childNode);
           }
        }
        
    }
    
    private void buildBranches( dataObject theDataObject, DefaultMutableTreeNode parentNode)
    {
        DefaultMutableTreeNode childNode;
        Enumeration dataLinkList = theDataObject.getOutLinkData();
        dataLink tempLink;
        
        while( dataLinkList.hasMoreElements() )
        {
            tempLink = (dataLink)dataLinkList.nextElement();
            childNode = new DefaultMutableTreeNode(tempLink.getPointee());
            parentNode.add(childNode);
        }
    }
    
    public void treeCollapsed( TreeExpansionEvent e) {}

    public void activate()
    {
        createTree();
        theDisplay.add(dataTree);
    }

    public void deActivate()
    {
        theDisplay.remove(dataTree);
    }

    private void createTree()
    {

    
        DefaultMutableTreeNode top = new DefaultMutableTreeNode("Root Node");
        
        createNodes(top);
        
        dataTree = new JTree(top);
        
        dataTree.setLocation(new java.awt.Point(10, 10));
        dataTree.setVisible(true);
        dataTree.setSize(new java.awt.Dimension(400, 400));
        
        dataTree.addTreeExpansionListener(this);
    }

   
   private void createNodes(DefaultMutableTreeNode top) 
   {
        Enumeration dataList = theData.getData();
        Enumeration dataLinkList;
        dataObject tempObject;
        dataLink   tempLink;
   
        DefaultMutableTreeNode level1 = null;
        DefaultMutableTreeNode level2 = null;

        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            level1 = new DefaultMutableTreeNode(tempObject);
            top.add(level1);
            
            if(tempObject.getOutLinkNumber() > 0 )
            {
                buildBranches(tempObject, level1);
                /*dataLinkList = tempObject.getOutLinkData();
                
                while( dataLinkList.hasMoreElements() )
                {
                    tempLink = (dataLink)dataLinkList.nextElement();
                    level2 = new DefaultMutableTreeNode(tempLink.getPointee());
                    level1.add(level2);
                }*/

            }
        }
    }



    //---------------------------------------------------------------
    // Mouse listener methods
    //---------------------------------------------------------------
    public void mouseClicked(MouseEvent e) {}
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    //---------------------------------------------------------------
    // Mouse Motion listener methods
    //---------------------------------------------------------------
    public void mouseDragged(MouseEvent e) {}
    public void mouseMoved(MouseEvent e ) {}

    public void update()
    {
        theDisplay.repaint();
    }

    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    public void paint(Graphics g)
    {

        //g.drawString("Tree View does nothing yet...", 50,50);
    }

    //---------------------------------------------------------------
    // Key listener methods
    //---------------------------------------------------------------
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
    
}
