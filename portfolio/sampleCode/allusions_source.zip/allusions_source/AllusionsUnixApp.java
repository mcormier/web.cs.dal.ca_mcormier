/**
*  AllusionsUnixApp.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Wed June 18 2003.
*
*
* @deprecated 	This class was written to temporarily test allusions
*		while removing com.apple.eawt code.  You are now requested
*		to use allusionsApp.java and compile it with eawtSTUBS.jar
*		if you are compiling on a non Mac OS or are using a java
*		version less than 1.4
*/

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.EventListener;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AllusionsUnixApp extends JFrame
//    implements  ActionListener
{
/*  
    private ViewManager viewManager;
  
    //These constants should be stored in a preferences file
    private static final int WINDOW_WIDTH  = 640;
    private static final int WINDOW_HEIGHT = 480;

    private Font font = new Font("serif", Font.ITALIC+Font.BOLD, 36);

    //private  com.apple.eawt.Application theApp;

    protected ResourceBundle resbundle;
    protected AboutBox aboutBox;

    // Declarations for menus
    static final JMenuBar mainMenuBar = new JMenuBar();
	
    protected JMenu fileMenu; 
    protected JMenuItem miNew;
    protected JMenuItem miOpen;
    protected JMenuItem miClose;
    protected JMenuItem miSave;
    protected JMenuItem miSaveAs;
	
    protected JMenu editMenu;
    protected JMenuItem miUndo;
    protected JMenuItem miCut;
    protected JMenuItem miCopy;
    protected JMenuItem miPaste;
    protected JMenuItem miClear;
    protected JMenuItem miSelectAll;


    
    public void addFileMenuItems() 
    {
        miNew = new JMenuItem (resbundle.getString("newItem"));
        miNew.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miNew).setEnabled(true);
        miNew.addActionListener(this);
        
        miOpen = new JMenuItem (resbundle.getString("openItem"));
        miOpen.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miOpen).setEnabled(true);
        miOpen.addActionListener(this);
		
        miClose = new JMenuItem (resbundle.getString("closeItem"));
        miClose.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miClose).setEnabled(true);
        miClose.addActionListener(this);
		
        miSave = new JMenuItem (resbundle.getString("saveItem"));
        miSave.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miSave).setEnabled(true);
        miSave.addActionListener(this);
		
        miSaveAs = new JMenuItem (resbundle.getString("saveasItem"));
        fileMenu.add(miSaveAs).setEnabled(true);
        miSaveAs.addActionListener(this);
		
        mainMenuBar.add(fileMenu);
    }
	
	
    public void addEditMenuItems() 
    {
        miUndo = new JMenuItem(resbundle.getString("undoItem"));
        miUndo.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miUndo).setEnabled(true);
        miUndo.addActionListener(this);
        editMenu.addSeparator();

        miCut = new JMenuItem(resbundle.getString("cutItem"));
        miCut.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miCut).setEnabled(true);
        miCut.addActionListener(this);

        miCopy = new JMenuItem(resbundle.getString("copyItem"));
        miCopy.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miCopy).setEnabled(true);
        miCopy.addActionListener(this);

        miPaste = new JMenuItem(resbundle.getString("pasteItem"));
        miPaste.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miPaste).setEnabled(true);
        miPaste.addActionListener(this);

        miClear = new JMenuItem(resbundle.getString("clearItem"));
        editMenu.add(miClear).setEnabled(true);
        miClear.addActionListener(this);
        editMenu.addSeparator();

        miSelectAll = new JMenuItem(resbundle.getString("selectAllItem"));
        miSelectAll.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miSelectAll).setEnabled(true);
        miSelectAll.addActionListener(this);

        mainMenuBar.add(editMenu);
    }

      
    
    public void addMenus() 
    {
        editMenu = new JMenu(resbundle.getString("editMenu"));
        fileMenu = new JMenu(resbundle.getString("fileMenu"));
   
        addFileMenuItems();
        addEditMenuItems();

        setJMenuBar (mainMenuBar);
    }

    public AllusionsUnixApp() 
    {	
        super("");
        
         
        // The ResourceBundle below contains all of the strings used in this application.  ResourceBundles
        // are useful for localizing applications - new localities can be added by adding additional 
        // properties files.  
        resbundle = ResourceBundle.getBundle ("allusionsAppstrings", Locale.getDefault());
       	setTitle(resbundle.getString("frameConstructor"));

	
        addMenus();

        aboutBox = new AboutBox();
        Toolkit.getDefaultToolkit();
         
        //theApp = new Application();
        //theApp.addApplicationListener(this);
     
        setSize(WINDOW_WIDTH,WINDOW_HEIGHT);
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        viewManager = new ViewManager(getContentPane(),mainMenuBar);
        
       }
    
 
    public void handleAbout(ApplicationEvent e) 
    {
        aboutBox.setResizable(false);
        aboutBox.setVisible(true);
        aboutBox.show();
    }

    public void handleOpenApplication(ApplicationEvent e) { }
    public void handleOpenFile(ApplicationEvent e) { }
    public void handlePreferences(ApplicationEvent e) { }
    public void handlePrintFile(ApplicationEvent e) { }
    
    public void handleQuit(ApplicationEvent e) 
    {	
 
        //Save Preferences 
        
        //prompt if data not saved
 
        System.exit(0);
    }

    // ActionListener interface (for menus)
    public void actionPerformed(ActionEvent newEvent) {
        if (newEvent.getActionCommand().equals(miNew.getActionCommand())) doNew();
        else if (newEvent.getActionCommand().equals(miOpen.getActionCommand())) doOpen();
        else if (newEvent.getActionCommand().equals(miClose.getActionCommand())) doClose();
        else if (newEvent.getActionCommand().equals(miSave.getActionCommand())) doSave();
        else if (newEvent.getActionCommand().equals(miSaveAs.getActionCommand())) doSaveAs();
        else if (newEvent.getActionCommand().equals(miUndo.getActionCommand())) doUndo();
        else if (newEvent.getActionCommand().equals(miCut.getActionCommand())) doCut();
        else if (newEvent.getActionCommand().equals(miCopy.getActionCommand())) doCopy();
        else if (newEvent.getActionCommand().equals(miPaste.getActionCommand())) doPaste();
        else if (newEvent.getActionCommand().equals(miClear.getActionCommand())) doClear();        
        else if (newEvent.getActionCommand().equals(miSelectAll.getActionCommand())) doSelectAll();
    }

    public void doNew() {}
	
    public void doOpen() {}
	
    public void doClose() {}
	
    public void doSave() {}
	
    public void doSaveAs() {}
	
    public void doUndo() {}
	
    public void doCut() {}
	
    public void doCopy() {}
	
    public void doPaste() {}
	
    public void doClear() {}
	
    public void doSelectAll() {}

 
    public static void main(String args[]) 
    {
        AllusionsUnixApp daApp = new AllusionsUnixApp();
        daApp.show();       
    }

    private void println( String toPrint)
    {
        System.out.println(toPrint);
    }
*/    
}
