/*
 *  allusionsApp.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Fri Apr 25 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
 //Projectbuilder CVS integration test
 
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.EventListener;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;

import simple.logging.Log;

import org.tigris.gef.util.*;
import org.gjt.sp.jedit.gui.SplashScreen;

// Includes ApplicationListener and ApplicationEvent which are used to make
// a java program look more like a Mac program on OS X
// link to eawtStubs.jar if you are compiling on other systems
import com.apple.eawt.*;

// Implements the singleton pattern (only one allusionsApp should ever be running)

public class allusionsApp extends JFrame
    implements  ActionListener, ApplicationListener, WindowListener
{
 
    private static allusionsApp SINGLETON;  
    
    // is the program being run on a MAC and using Aqua Look and Feel?
    private  static boolean _isAqua;

    static 
    {
        // Check for aqua before instantiating so that menubar properties
        // are set before creating the main JFrame
        _isAqua = ApplicationUtilities.isAqua();        
        SINGLETON = new allusionsApp();  
    }  

  
    private ViewManager viewManager;
  
    private ApplicationPreferences preferences;
  
    private Font font = new Font("serif", Font.ITALIC+Font.BOLD, 36);

    //use for registering with Mac OS 10.2.3 or greater
    private  com.apple.eawt.Application theApp;
    
    //Pull menu strings out of a bundle to allow localization in the future
    protected ResourceBundle resbundle;
    protected AboutBox aboutBox;

    //Has the data the user is manipulated been saved to a file
    //or been loaded from a file
    private  boolean dataAssocWithFile;
    
    
    // The absolute path of where to save data
    // Set when file is loaded or saved
    private  String  whereToSaveData;

    public  String  lastSaveDir;
    public  String  lastOpenDir;

    // Declarations for menus
    private JMenuBar mainMenuBar = new JMenuBar();
        
    protected JMenu fileMenu; 
    protected JMenuItem miNew;
    protected JMenuItem miOpen;
    protected JMenuItem miClose;
    protected JMenuItem miSave;
    protected JMenuItem miSaveAs;
	
    protected JMenu editMenu;
    protected JMenuItem miUndo;
    protected JMenuItem miCut;
    protected JMenuItem miCopy;
    protected JMenuItem miPaste;
    protected JMenuItem miClear;
    protected JMenuItem miSelectAll;

    protected JMenu helpMenu;
    protected JMenuItem miAbout;

    private void addhelpMenuItems() 
    {
        miAbout = new JMenuItem (resbundle.getString("aboutItem"));
        helpMenu.add(miAbout).setEnabled(true);
        miAbout.addActionListener(this);
    
        mainMenuBar.add(helpMenu);
    }
    
    
    private void addFileMenuItems() 
    {
        miNew = new JMenuItem (resbundle.getString("newItem"));
        miNew.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miNew).setEnabled(true);
        miNew.addActionListener(this);
        
        miOpen = new JMenuItem (resbundle.getString("openItem"));
        miOpen.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_O, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miOpen).setEnabled(true);
        miOpen.addActionListener(this);
		
        miClose = new JMenuItem (resbundle.getString("closeItem"));
        miClose.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_W, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miClose).setEnabled(true);
        miClose.addActionListener(this);
		
        miSave = new JMenuItem (resbundle.getString("saveItem"));
        miSave.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        fileMenu.add(miSave).setEnabled(true);
        miSave.addActionListener(this);
		
        miSaveAs = new JMenuItem (resbundle.getString("saveasItem"));
        fileMenu.add(miSaveAs).setEnabled(true);
        miSaveAs.addActionListener(this);
              
        mainMenuBar.add(fileMenu);
    }
	
	
    private void addEditMenuItems() 
    {
        miUndo = new JMenuItem(resbundle.getString("undoItem"));
        miUndo.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miUndo).setEnabled(true);
        miUndo.addActionListener(this);
        editMenu.addSeparator();

        miCut = new JMenuItem(resbundle.getString("cutItem"));
        miCut.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miCut).setEnabled(true);
        miCut.addActionListener(this);

        miCopy = new JMenuItem(resbundle.getString("copyItem"));
        miCopy.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miCopy).setEnabled(true);
        miCopy.addActionListener(this);

        miPaste = new JMenuItem(resbundle.getString("pasteItem"));
        miPaste.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miPaste).setEnabled(true);
        miPaste.addActionListener(this);

        miClear = new JMenuItem(resbundle.getString("clearItem"));
        editMenu.add(miClear).setEnabled(true);
        miClear.addActionListener(getApp());
        editMenu.addSeparator();

        miSelectAll = new JMenuItem(resbundle.getString("selectAllItem"));
        miSelectAll.setAccelerator(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
        editMenu.add(miSelectAll).setEnabled(true);
        miSelectAll.addActionListener(this);

        mainMenuBar.add(editMenu);
    }

      
    
    private void addMenus() 
    {
        editMenu = new JMenu(resbundle.getString("editMenu"));
        fileMenu = new JMenu(resbundle.getString("fileMenu"));
        helpMenu = new JMenu(resbundle.getString("helpMenu"));
   
        addFileMenuItems();
        addEditMenuItems();
        
        // Send the viewManager the mainMenuBar so that it can add
        // and manage a view list
        viewManager = new ViewManager(getContentPane(),mainMenuBar);
     
       if( !_isAqua )
            addhelpMenuItems();

        setJMenuBar (mainMenuBar);
    }

    //---------------------------------------------------------------
    // Private constructor so it cannot be instantiated.
    //---------------------------------------------------------------
    private allusionsApp() 
    {	
        super("");
       
       SplashScreen splash = new SplashScreen();
       
       
         //setup our image loader
        ResourceLoader.addResourceExtension("gif");
        ResourceLoader.addResourceExtension("png");
        ResourceLoader.addResourceLocation("/images");
        //Should Preload data Objects here
        
        dataAssocWithFile = false;
        
        
        // The ResourceBundle below contains all of the strings used in this application.  ResourceBundles
        // are useful for localizing applications - new localities can be added by adding additional 
        // properties files.  
        resbundle = ResourceBundle.getBundle ("allusionsAppstrings", Locale.getDefault());
       	setTitle(resbundle.getString("frameConstructor"));
	
        addMenus();

        
        Toolkit.getDefaultToolkit();

        // register with OS X 
        // this handles things such as hiding the app (COMMAND-H)
        theApp = new Application();
        theApp.addApplicationListener(this);
     
        addWindowListener(this);
     
        // If the user clicks close on the frame do nothing
        // let our windowListener method take care of it
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        
       
        Log.turnOff();
        preferences = ApplicationPreferences.getPreferences();
        preferences.loadPreferences(this); 
        Log.turnOn();
        
        splash.dispose();
              
    }
    
    public ViewManager getViewManager() { return viewManager; }
 
 
    public void handleAbout(ApplicationEvent e) 
    {
        doAbout();
    }

    public void doAbout()
    {
        aboutBox = new AboutBox( this );
    }

	public void handleReOpenApplication(ApplicationEvent e) { }
    public void handleOpenApplication(ApplicationEvent e) { }
    public void handleOpenFile(ApplicationEvent e) { }
    public void handlePreferences(ApplicationEvent e) { }
    public void handlePrintFile(ApplicationEvent e) { }
    
    public void handleQuit(ApplicationEvent e) 
    {	
        // Save Preferences 
        Log.turnOff();
        preferences.savePreferences(this);
        Log.turnOn();
        
        // Prompt if data not saved
 
        System.exit(0);
    }

    // ActionListener interface (for menus)
    public void actionPerformed(ActionEvent newEvent) {
        if (newEvent.getActionCommand().equals(miNew.getActionCommand())) doNew();
        else if (newEvent.getActionCommand().equals(miOpen.getActionCommand())) doOpen();
        else if (newEvent.getActionCommand().equals(miClose.getActionCommand())) doClose();
        else if (newEvent.getActionCommand().equals(miSave.getActionCommand())) doSave();
        else if (newEvent.getActionCommand().equals(miSaveAs.getActionCommand())) doSaveAs();
        else if (newEvent.getActionCommand().equals(miUndo.getActionCommand())) doUndo();
        else if (newEvent.getActionCommand().equals(miCut.getActionCommand())) doCut();
        else if (newEvent.getActionCommand().equals(miCopy.getActionCommand())) doCopy();
        else if (newEvent.getActionCommand().equals(miPaste.getActionCommand())) doPaste();
        else if (newEvent.getActionCommand().equals(miClear.getActionCommand())) doClear();        
        else if (newEvent.getActionCommand().equals(miSelectAll.getActionCommand())) doSelectAll();
        else if (newEvent.getActionCommand().equals(miAbout.getActionCommand())) doAbout();
    }

    public void doNew() {}	
   
    
    public void doOpen() 
    {
    
        // ------------- Sun Aug 31 2003 --------------------------------
        // http://developer.apple.com/technotes/tn/tn2042.html#Section1_7
        //
        // File Dialogs in Aqua
        //
        // The java.awt.FileDialog and javax.swing.JFileChooser classes are the two main 
        // mechanisms to create quick and easy access to the file system for the user of your 
        // Java application.  JFileChooser is the newer, abstracted, more-customizable 
        // successor to the older, native-derived AWT FileDialog.  Each has its advantage over 
        // the other.                    
        //
        // In the interest of making your application look as "native" as possible, it is 
        // typically recommended that developers use the AWT FileDialog classes to present file 
        // access to the user.  The difference between the two is especially visible when using 
        // Aqua on Mac OS X, where file dialogs in Carbon and Cocoa applications use a "column" 
        // style of navigation.  This is adopted automatically by the AWT FileDialog, while the 
        // Swing JFileChooser uses a navigation style different than that of typical Mac OS X 
        // Applications.  However, the many functional advantages of JFileChooser may outweigh 
        // this suggestion.  The choice is up to the developer.  Please note that there is no 
        // consequence to mixing a heavyweight FileDialog with an otherwise-Swing application, 
        // as the dialog is modal and will always draw on top of the other visible components.        
        
        if( _isAqua )
        {
            FileDialog fileDialog = new FileDialog( this, "Open", java.awt.FileDialog.LOAD);
            fileDialog.setDirectory(lastOpenDir);
            
            fileDialog.show();
            
            String filename = fileDialog.getFile();
            
            if (filename != null )
            {
                File openFile = new File( fileDialog.getDirectory() , filename);

                dataManager dm = dataManager.getDataManager();
                dm.loadData( openFile );
                
                whereToSaveData = fileDialog.getDirectory() + filename;
                
                lastOpenDir = fileDialog.getDirectory();
                dataAssocWithFile = true;

            }
            
        }
        else
        {
            //prompt for fileName
            JFileChooser chooser = new JFileChooser(lastOpenDir);
        
            int returnVal = chooser.showOpenDialog(this);
    
            if(returnVal == JFileChooser.APPROVE_OPTION) 
            {
                dataManager dm = dataManager.getDataManager();
                
                dm.loadData( chooser.getSelectedFile() );
                
                whereToSaveData = chooser.getSelectedFile().getAbsolutePath();
                lastOpenDir = chooser.getSelectedFile().getParent();
                dataAssocWithFile = true;
            }
        }
        
        
    }	
    public void doClose() 
    {
        //prompt user if data modified and not saved
    
        //clear dataManager
        
        
        dataAssocWithFile = false;
    }	
    
    
    public void doSave() 
    {
        if(dataAssocWithFile)
        {
            dataManager dm = dataManager.getDataManager();
            dm.saveData( new File(whereToSaveData) );
        }
        else
            doSaveAs();
    }	
    
    public void doSaveAs() 
    {
    
        // ------------- Sun Aug 31 2003 --------------------------------
        // http://developer.apple.com/technotes/tn/tn2042.html#Section1_7
        //
        // File Dialogs in Aqua
        //
        // The java.awt.FileDialog and javax.swing.JFileChooser classes are the two main 
        // mechanisms to create quick and easy access to the file system for the user of your 
        // Java application.  JFileChooser is the newer, abstracted, more-customizable 
        // successor to the older, native-derived AWT FileDialog.  Each has its advantage over 
        // the other.                    
        //
        // In the interest of making your application look as "native" as possible, it is 
        // typically recommended that developers use the AWT FileDialog classes to present file 
        // access to the user.  The difference between the two is especially visible when using 
        // Aqua on Mac OS X, where file dialogs in Carbon and Cocoa applications use a "column" 
        // style of navigation.  This is adopted automatically by the AWT FileDialog, while the 
        // Swing JFileChooser uses a navigation style different than that of typical Mac OS X 
        // Applications.  However, the many functional advantages of JFileChooser may outweigh 
        // this suggestion.  The choice is up to the developer.  Please note that there is no 
        // consequence to mixing a heavyweight FileDialog with an otherwise-Swing application, 
        // as the dialog is modal and will always draw on top of the other visible components.        
        
        if( _isAqua )
        {
            FileDialog fileDialog = new FileDialog( this, "Save as", java.awt.FileDialog.SAVE);
            fileDialog.setDirectory(lastSaveDir);
            
            fileDialog.show();
            
            String filename = fileDialog.getFile();
            
            if (filename != null )
            {
                File saveFile = new File( fileDialog.getDirectory() , filename);

                dataManager dm = dataManager.getDataManager();
                dm.saveData( saveFile );
                
                whereToSaveData = fileDialog.getDirectory() + filename;
                
                lastSaveDir = fileDialog.getDirectory();
                dataAssocWithFile = true;
            }
            
        }
        else
        {
            // prompt for fileName
            JFileChooser chooser = new JFileChooser(lastSaveDir);
        
            int returnVal = chooser.showSaveDialog(this);
    
            if(returnVal == JFileChooser.APPROVE_OPTION) 
            {
                dataManager dm = dataManager.getDataManager();
                dm.saveData( chooser.getSelectedFile() );
    
                whereToSaveData = chooser.getSelectedFile().getAbsolutePath();
                
                lastSaveDir = chooser.getSelectedFile().getParent();
                dataAssocWithFile = true;
            }
        }
    }	
    
    public void doUndo() {}	
    public void doCut() {}	
    public void doCopy() {}	
    public void doPaste() {}	
    public void doClear() {}	
    public void doSelectAll() {}

    //WindowListener Methods
    
    public void windowActivated(WindowEvent e) {}
    public void windowClosed(WindowEvent e) {}
    
    
    //This method and handleQuit are currently identical 
    //TODO: create helper method that each calls
    public void windowClosing(WindowEvent e) 
    {
        // Save Preferences 
        preferences.savePreferences(this);
        
        // Prompt if data not saved
 
        System.exit(0);
    }    
    
    public void windowDeactivated(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}     
    public void windowOpened(WindowEvent e) {}

    //---------------------------------------------------------------   
    // Returns the instance of the allusionsApp singleton.  
    //---------------------------------------------------------------     
    public static allusionsApp getApp()
    {
        return SINGLETON;
    }


    public static void main(String args[]) 
    {
        allusionsApp daApp = allusionsApp.getApp();
        daApp.show();       
    }
    
}
