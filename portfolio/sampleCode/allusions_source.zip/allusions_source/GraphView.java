/*
 *  GraphView.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Mon Jun 09 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import simple.logging.Log;

public class GraphView extends View
                       implements MouseListener, MouseMotionListener, KeyListener
{
    protected dataManager 		theData;
    protected View 			parent;

    protected boolean drawSelectionBox, dragSelected, holdingShift;

    protected int selectBox_X, selectBox_Y,
                lastClick_X, lastClick_Y,
                selectBox_width, selectBox_height,
                currentMouseX, currentMouseY;

    protected JPopupMenu tempPopup;

    public GraphView( dataManager theDataManager)
    {
        super();
        theData = theDataManager;
        theData.attach(this);

                        
        setOpaque(true);
        setBackground( new java.awt.Color(255,255,255) );
        
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        
        //for some reason this line activates the key listener
        //and then all keys can be captured in the key listener methods
        getInputMap().put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_BACK_SPACE,0), "doSomething");
    
    
        //This should be extrapolated from data
        setPreferredSize(new Dimension(640, 480));
    
    }
    
    public void setParent( View parentView)
    {
        parent = parentView;
    }
          
     //---------------------------------------------------------------
    // Mouse listener methods
    //---------------------------------------------------------------
    public void mouseClicked(MouseEvent e) { }
   
     
    public void mousePressed(MouseEvent e)  
    { 
    
        if( theData.creatingNewLink() )
        {
            //create link if valid
            theData.finishNewLink( e.getX() , e.getY() );
               
         }


        if( maybeShowPopup(e) ) {}
        else
        {
            if( theData.selectDataObject( e.getX() , e.getY(), holdingShift ) )
                      dragSelected = true;
            else //For drawing selection rectangle
            {
                drawSelectionBox = true;
                selectBox_X = e.getX();
                selectBox_Y = e.getY();
            }
            
        }
    }

    public void mouseReleased(MouseEvent e) 
    {
        dragSelected = false; 
       
        selectBox_width = 0;
        selectBox_height = 0;
        drawSelectionBox = false;
        
        maybeShowPopup(e); 
        update();
    }


    private boolean maybeShowPopup(MouseEvent e) 
    {

    	if (e.isPopupTrigger()) 
    	{
    		lastClick_X = e.getX();
    		lastClick_Y = e.getY();

                if( theData.isDataObject( e.getX(),  e.getY() ) )
                {
                    tempPopup = theData.getDataObjectPopup( e.getX(),  e.getY() );
                    tempPopup.setInvoker (this);
                    tempPopup.show(e.getComponent(), e.getX(), e.getY()); 
                }
                else
                {
                    tempPopup = theData.getDefaultPopup( e.getX(), e.getY() );
                    tempPopup.setInvoker (this);
                    tempPopup.show(e.getComponent(), e.getX(), e.getY()); 
                }
                
                return true;
        }
        
        return false;
    }
    
    

     //---------------------------------------------------------------
    // Mouse Motion listener methods
    //---------------------------------------------------------------
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e)  {}
    
    public void mouseDragged(MouseEvent e) 
    {
        if(dragSelected)
        {
            theData.moveSelected(e.getX() , e.getY() );
            update();
            return;
        }
        
        if(drawSelectionBox)
        {
            selectBox_width = e.getX() - selectBox_X;
            selectBox_height = e.getY() - selectBox_Y;
            theData.multipleSelectBox( selectBox_X,selectBox_Y,selectBox_width,selectBox_height,holdingShift);
            update();
        }
        
    }
    
    public void mouseMoved(MouseEvent e ) 
    {
        if( theData.creatingNewLink() )
        {
            currentMouseX = e.getX();
            currentMouseY = e.getY();
            update();
        }
    }
 


    public void update()
    {        
        repaint();
    }

    public void update(Graphics g)
    {
        super.update(g);
        paint(g);
    }

    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    public void paint(Graphics g)
    { 
        super.paint(g);
        
        if( theData.creatingNewLink() )
        {
            g.setColor( java.awt.Color.black );
            g.drawLine(lastClick_X,lastClick_Y,currentMouseX,currentMouseY);
        }

   
        paintData(g);

        if(drawSelectionBox)
        {
            g.setColor( java.awt.Color.black );
            int tempX = selectBox_X; 
            int tempY = selectBox_Y;
            
            //drawRect doesn't like negative heights or widths
            if ( selectBox_height < 0 ) 
                tempY = selectBox_Y + selectBox_height; 
            if ( selectBox_width < 0 ) 
                tempX = selectBox_X + selectBox_width;
            
            g.drawRect( tempX, tempY, Math.abs(selectBox_width), Math.abs(selectBox_height) );
            
        }
        
     }


    protected void paintData( Graphics g)
    {
        Point boxPoint;
        dataObject tempObject;

    
        g.setColor(new java.awt.Color(0,255,0) );

        //paint non selected objects 
        Enumeration dataList = theData.getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            tempObject.paint(g);
        }
        
        //paint selected objects last
        //dataList = theData.getSelectedData();
        
        //while( dataList.hasMoreElements() )
        //{
        //    tempObject = (dataObject)dataList.nextElement();

        //    tempObject.paintSelected(g);
        //}


    }

    //
    //  
    //
    public void editObject(EditPanel editPanel)
    {
        // The View has no parent so display the data in a JDialog
        if( parent == null)
        {
            JDialog theDialog = new JDialog( allusionsApp.getApp() ,"", true);
    
            editPanel.attachToDialog( theDialog );
            theDialog.pack();
            theDialog.show();
                
            theDialog.dispose();
        }
        if( parent != null)
        {
            //pass the panel up to the parent View and let it decide what to do
            parent.editObject(editPanel);
        }
    }

     //---------------------------------------------------------------
    // Key listener methods
    //---------------------------------------------------------------
    public void keyPressed(KeyEvent e) 
    {
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_BACK_SPACE )
        {
            theData.deleteSelected();
            update();
        }
        
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_SHIFT )
        {
            holdingShift = true;
        }
     
    }

    public void keyReleased(KeyEvent e) 
    { 
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_SHIFT )
        {
            holdingShift = false;
        }
    }

    public void keyTyped(KeyEvent e) {}


}
