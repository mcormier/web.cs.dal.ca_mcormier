//
//  box.java
//  allusionsApp
//
//  Created by Matthieu Cormier on Tue May 27 2003.
//
//	THIS CLASS HAS BEEN REPLACED BY JAVA.AWT.GEOM.RECTANGLE
//

import java.awt.Point;

public class box 
{

    Line top, right, left, bottom;
    
    box( Point topLeftCorner, int width, int height)
    {
        top    = new Line( topLeftCorner.x, topLeftCorner.y, topLeftCorner.x + width, topLeftCorner.y);
        right  = new Line( topLeftCorner.x + width, topLeftCorner.y, topLeftCorner.x + width, topLeftCorner.y + height );
        bottom = new Line (topLeftCorner.x, topLeftCorner.y + height, topLeftCorner.x + width, topLeftCorner.y + height );
        left   = new Line(topLeftCorner.x, topLeftCorner.y, topLeftCorner.x, topLeftCorner.y + height );
    }

    public Line getTop()    { return top; }
    public Line getRight()  { return right; } 
    public Line getLeft()   { return left; }
    public Line getBottom() { return bottom; }
    
    public Line[] getSides()
    {
        Line[] toReturn = { top, right, left, bottom};
        
        return toReturn;
    }
}
