/*
 *  linkLine.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Wed June 5 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import simple.logging.Log;

public class linkLine extends Object
{
	public int X0, Y0;
	public int X1, Y1;
	public int Yintercept;
	public float Slope;
	
        
	linkLine ( Point start, Point end )
	{
		X0 = start.x;
		Y0 = start.y;
		X1 = end.x;
		Y1 = end.y;
		
		calculateSlope();
		calculateYIntercept();
	}
	
        linkLine ( int startX, int startY, int endX, int endY )
        {
            this( new Point(startX,startY), new Point(endX,endY) );
        }
        
	private void calculateYIntercept()
	{
		Yintercept = (int)(Y0 - (Slope * X0));
	}
	
	private void calculateSlope()
	{
		int DeltaX, DeltaY;
	
		DeltaX = X1 - X0;
		DeltaY = Y1 - Y0;
		
		Slope = (float)DeltaY / DeltaX;	/*Find slope of the line		y = [m]x + b */
	}
	
	public void setStartPoint( Point start ) 
	{ 
		X0 = start.x;
		Y0 = start.y;
		
		calculateSlope();	
		calculateYIntercept();	
	}

	public void setEndPoint( Point end ) 
	{ 
		X1 = end.x;
		Y1 = end.y;
		
		calculateSlope();
		calculateYIntercept();
	}
	
	public Line getPerpendicularLine(Point start, float width)
	{
		float perpSlope = -Slope;
		float perpYIntercept = -(start.x * perpSlope) + start.y;
		float theta = (float)Math.atan( perpSlope ); 
		
		int yDistance = (int) (Math.cos(theta) * (width / 2));		
		int xDistance = (int) (Math.sin(theta) * (width / 2));				

		Point perpEnd   = new Point(0,0);
		Point perpStart = new Point(0,0);


		if(X0 <= X1)
		{
			perpStart.x = start.x + xDistance;
			perpStart.y = start.y + yDistance;
			perpEnd.x = start.x - xDistance;
			perpEnd.y = start.y - yDistance;
		}
		else
		{
			perpStart.x = start.x - xDistance;
			perpStart.y = start.y - yDistance;
			perpEnd.x = start.x + xDistance;
			perpEnd.y = start.y + yDistance;
		
		}
		
	
		return new Line(perpStart,perpEnd);
	}
		
	public int calculateY( int X )
	{
            //y = mx + b
            return Math.round((Slope * X) + Yintercept);
	}

	public int calculateY( float X )
	{
            //y = mx + b
            return (int)( (Slope * X) + Yintercept);
	}


	public int calculateX( int Y )
	{
            // BUG 759329 FIX
            // ==============
            // Description: Vertical Datalinks jump to left
            // --------------------------------------------------------
            // Create two dataObjects and connect them with a datalink.   
            // Make the datalink vertical and completely straight, the  
            // datalink will jump to the side of the screen and not be  
            // attached to either dataObject.     
            // --------------------------------------------------------
            // FIX:
            // if slope is infinite return an X since our line
            // is most likely a vertical line where X does not change
            if ( Float.isInfinite(Slope) ) return X0;
            
            //x = (y - b)/x
            return (int)( (Y - Yintercept) / Slope );
	}

	public int calculateX( float Y )
	{
             //x = (y - b)/x
            return (int)( (Y - Yintercept) / Slope );
	}
	
	

        
	
	public void println( String toPrint)
	{
		System.out.println(toPrint);
	}
	


    //optimize if necessary later
    public Point getIntersectionPointfromRect(Rectangle rect)
    {
        //test TOP of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY(),  
                                                rect.getX() + rect.getWidth(), rect.getY() ) )
        {
           
            return new Point( calculateX((int)rect.getY()), (int)rect.getY() );
        }
        
        //test RIGHT side of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX() + rect.getWidth(), rect.getY(),  
                                                rect.getX() + rect.getWidth(), rect.getY() + rect.getHeight() ) )
        {
            return new Point( (int)(rect.getX() + rect.getWidth()), calculateY((int)(rect.getX() + rect.getWidth())) );
        }

        //test LEFT side of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY(),  
                                                rect.getX(), rect.getY() + rect.getHeight() ) )
        {
            return new Point( (int)(rect.getX()), calculateY((int)(rect.getX())) );
        }

        //test BOTTOM of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY()  + rect.getHeight(),  
                                                rect.getX() + rect.getWidth(), rect.getY()  + rect.getHeight() ) )
        {
            return new Point( calculateX((int)(rect.getY()  + rect.getHeight()) ), (int)(rect.getY() + rect.getHeight() ) );
        }
      
        return null;
    }



    
	
	public String toString()
	{
		return ("Y = " + Slope + "X + " + Yintercept + "  Range (X0,Y0) (" + X0 + "," + Y0 + ") - (X1,Y1) (" + X1 + "," + Y1 + ")");
	}

}