/*
 *  TreeView.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Mon Jun 09 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JTree;
import javax.swing.tree.*;
import javax.swing.event.*;
import java.util.*;

public class TreeView 	extends    View
                        implements TreeExpansionListener
{
    private dataManager theData;


    private JTree   dataTree;

    public TreeView( dataManager theDataManager)
    {
        super();
        theData = theDataManager;
        theData.attach(this);
        
        setBackground( java.awt.Color.white  );
        setLayout(new BorderLayout());
        
        createTree();
        add(dataTree,BorderLayout.WEST );
    }

    public void treeExpanded( TreeExpansionEvent e)
    {
        TreePath thePath = e.getPath();
                
        DefaultMutableTreeNode tempNode = (DefaultMutableTreeNode)thePath.getPathComponent( thePath.getPathCount() - 1 );
        
        Enumeration childNodes = tempNode.children();
        
        while(childNodes.hasMoreElements() )
        {
           DefaultMutableTreeNode childNode = (DefaultMutableTreeNode)childNodes.nextElement();
           dataObject tempObject = (dataObject)childNode.getUserObject();
           
           if(tempObject.getOutLinkNumber() > 0 )
           {
                buildBranches(tempObject, childNode);
           }
        }
        
    }
    
    private void buildBranches( dataObject theDataObject, DefaultMutableTreeNode parentNode)
    {
        DefaultMutableTreeNode childNode;
        Enumeration dataLinkList = theDataObject.getOutLinkData();
        dataLink tempLink;
        
        while( dataLinkList.hasMoreElements() )
        {
            tempLink = (dataLink)dataLinkList.nextElement();
            childNode = new DefaultMutableTreeNode(tempLink.getPointee());
            parentNode.add(childNode);
        }
    }
    
    public void treeCollapsed( TreeExpansionEvent e) {}

  
    private void createTree()
    {
        DefaultMutableTreeNode top = new DefaultMutableTreeNode("Root Node");
        
        createNodes(top);
        
        dataTree = new JTree(top);
        
        //dataTree.setLocation(new java.awt.Point(10, 10));
        dataTree.setVisible(true);
        dataTree.setSize(new java.awt.Dimension(400, 400));
        
        dataTree.addTreeExpansionListener(this);

        // BUG 749936
        dataTree.setRootVisible(false);
        
    }

   
   private void createNodes(DefaultMutableTreeNode top) 
   {
        Enumeration dataList = theData.getData();
        Enumeration dataLinkList;
        dataObject tempObject;
        dataLink   tempLink;
   
        DefaultMutableTreeNode level1 = null;
        DefaultMutableTreeNode level2 = null;

        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            level1 = new DefaultMutableTreeNode(tempObject);
            top.add(level1);
            
            if(tempObject.getOutLinkNumber() > 0 )
            {
                buildBranches(tempObject, level1);
                /*dataLinkList = tempObject.getOutLinkData();
                
                while( dataLinkList.hasMoreElements() )
                {
                    tempLink = (dataLink)dataLinkList.nextElement();
                    level2 = new DefaultMutableTreeNode(tempLink.getPointee());
                    level1.add(level2);
                }*/

            }
        }
    }



 
    public void update()
    {	
        remove(dataTree);
        createTree();
        add(dataTree,BorderLayout.WEST);
    }

    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    public void paint(Graphics g)
    {
        super.paint(g);
        
        //dataTree.paint(g);
        //g.drawString("Tree View does nothing yet...", 50,50);
    }


    
    public void editObject(EditPanel editPanel) {}
}
