/*
 *  AllusionsDataModel.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Fri Jun 06 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.*;

import simple.logging.Log;

public class AllusionsDataModel extends DataModel
                                implements ActionListener
{
    private JPopupMenu graphPopup;
    protected JMenuItem miMovie, miBook, miTVSeries,miTVEpisode;
    
    private JPopupMenu dataObjPopup;
    protected static String EDIT_CHOSEN = "chose_edit";
    protected static String LINK_CHOSEN = "chose_link";

    private JPopupMenu tvEpisodePopup;
    protected JMenuItem miAttach, miDetach;
  
    private JPopupMenu tvSeriesPopup;
    protected JMenuItem miNewEpisode, miNewSeason;
  
    
    //used by editObject Method to determine which popup was
    //last requested, and ables retrieval of the view that requested it.
    private JPopupMenu lastSentPopup;

    private dataManager theData;

    private int lastClick_X, lastClick_Y;

    public AllusionsDataModel()
    {
        super();
        initializePopups();
    }

    //---------------------------------------------------------------
    // Popup Menus
    //---------------------------------------------------------------
    private void initializePopups()
    {
    
        //Create new objects popup
        graphPopup = new JPopupMenu();
        
    	miMovie = new JMenuItem("Add Movie");
        graphPopup.add(miMovie);
        miMovie.addActionListener(this);
        
        miBook = new JMenuItem("Add Book");
        graphPopup.add(miBook);
        miBook.addActionListener(this);
        
        miTVSeries = new JMenuItem("Add TV Series");
        graphPopup.add(miTVSeries);
        miTVSeries.addActionListener(this);

        miTVEpisode = new JMenuItem("Add TV Episode");
        graphPopup.add(miTVEpisode);
        miTVEpisode.addActionListener(this);
       
        dataObjPopup = new JPopupMenu();
        tvEpisodePopup = new JPopupMenu();
        tvSeriesPopup = new JPopupMenu();
        
        addDefaultEditCommandsToPopup( dataObjPopup );
        addDefaultEditCommandsToPopup( tvEpisodePopup );
        addDefaultEditCommandsToPopup( tvSeriesPopup );
                   
        //TV Episode specific menu items        
        tvEpisodePopup.addSeparator();
                 
        miAttach = new JMenuItem("Attach Episode to Series");
        miAttach.addActionListener(this);
        tvEpisodePopup.add(miAttach);
        
        miDetach  = new JMenuItem("Detach Episode from Series");
        miDetach.addActionListener(this);
        tvEpisodePopup.add(miDetach);     
        
        //TV Series specific menu items
        tvSeriesPopup.addSeparator();
                 
        miNewEpisode = new JMenuItem("Create new episode");
        miNewEpisode.addActionListener(this);
        tvSeriesPopup.add(miNewEpisode);
        
        miNewSeason = new JMenuItem("Create new season ");
        miNewSeason.addActionListener(this);
        tvSeriesPopup.add(miNewSeason);
        
        
   }

    private void addDefaultEditCommandsToPopup( JPopupMenu thePopup)
    {
         JMenuItem miEdit = new JMenuItem("Edit Properties");
         miEdit.setActionCommand(EDIT_CHOSEN);
         miEdit.addActionListener(this);
         thePopup.add(miEdit);
         
        JMenuItem miLink = new JMenuItem("Link to other object");
        miLink.setActionCommand(LINK_CHOSEN);
        miLink.addActionListener(this);   
        thePopup.add(miLink); 

    }

    public JPopupMenu getDefaultPopup(int x, int y) 
    {
        lastClick_X = x;
        lastClick_Y = y;
        
        lastSentPopup = graphPopup;
        return graphPopup; 
    }

    public JPopupMenu getDataObjectPopup(int x, int y) 
    { 
        dataObject tempObject;
        
        lastClick_X = x;
        lastClick_Y = y;

        tempObject = theData.getDataObject(x,y);
        
        
        if( TVEpisode.isA( tempObject) )
        {
            // Check if episode is attached to a series
            // and disable appropriate menu
            TVEpisode episode = (TVEpisode)tempObject;
            
            if( episode.isAttachedToSeries() )
            {
                miDetach.setEnabled(true);
                miAttach.setEnabled(false);
            }
            else
            {
                miDetach.setEnabled(false);
                miAttach.setEnabled(true);                
            }
            lastSentPopup = tvEpisodePopup;
            return tvEpisodePopup;
        }

        if( TelevisionSeries.isA( tempObject) )
        {
            lastSentPopup = tvSeriesPopup;
            return tvSeriesPopup;
        }

        lastSentPopup = dataObjPopup;
        return dataObjPopup; 
    }

    public void setDataManager(dataManager theManager) { theData = theManager; }

   //---------------------------------------------------------------
    // ActionListener interface (for popup menu)
    //---------------------------------------------------------------    
    public void actionPerformed(ActionEvent newEvent) 
    {
        String command = newEvent.getActionCommand();

        if (EDIT_CHOSEN.equals(command)) editObject();
        if (LINK_CHOSEN.equals(command)) addLink();
    
        if (newEvent.getActionCommand().equals(miMovie.getActionCommand())) doNewMovie();
        if (newEvent.getActionCommand().equals(miBook.getActionCommand())) doNewBook();
        if (newEvent.getActionCommand().equals(miTVSeries.getActionCommand())) doNewTVSeries();
        if (newEvent.getActionCommand().equals(miTVEpisode.getActionCommand())) doNewTVEpisode();
        
        //Attach TV episode to season
        if (newEvent.getActionCommand().equals(miAttach.getActionCommand())) attachEpisode();
        //Detach TV episode from season
        if (newEvent.getActionCommand().equals(miDetach.getActionCommand())) detachEpisode();
        
        //Create new TV episode for a series
        if (newEvent.getActionCommand().equals(miNewEpisode.getActionCommand())) createNewEpisode();
        //
        if (newEvent.getActionCommand().equals(miNewSeason.getActionCommand())) _createNewSeason();
    }
    
    public void createNewEpisode()
    {
        allusionDataObject theObject = (allusionDataObject)theData.getDataObject(lastClick_X,lastClick_Y);
        
         if(TelevisionSeries.isA( theObject ) )
         {
            TelevisionSeries tvSeries = (TelevisionSeries) theObject;
            
            TVEpisode newEP = new TVEpisode(0,0);
            
            tvSeries.addEpisode( newEP );
            theData.addDataObject( newEP );
         }
    }
 
   private void _createNewSeason()
    {
        allusionDataObject theObject = (allusionDataObject)theData.getDataObject(lastClick_X,lastClick_Y);
        
         if(TelevisionSeries.isA( theObject ) )
         {
            TelevisionSeries tvSeries = (TelevisionSeries) theObject;
            
            Season newSeason = new Season( tvSeries );
            
            tvSeries.addSeason( newSeason );
            
         }
    }
    
       
             
    public void attachEpisode()
    {
        allusionDataObject theObject = (allusionDataObject)theData.getDataObject(lastClick_X,lastClick_Y);
    
        //send message to current invoker of popUP        
        AllusionView currentView = (AllusionView)lastSentPopup.getInvoker();

        if(TVEpisode.isA( theObject ) )
            currentView.attachEpisodeToSeries( (TVEpisode)theObject );

    }

    public void detachEpisode()
    {
        allusionDataObject theObject = (allusionDataObject)theData.getDataObject(lastClick_X,lastClick_Y);

        if(TVEpisode.isA( theObject ) )
        {
            TVEpisode episode = (TVEpisode)theObject;
            episode.detachFromSeries();
        }
   
    }

    public void doNewMovie() 
    { 
       theData.addDataObject(new movieDataObject(lastClick_X,lastClick_Y) );
    }

    public void doNewBook()
    {
        theData.addDataObject( new bookDataObject(lastClick_X,lastClick_Y) );
    }
 
    public void doNewTVSeries() 
    { 
       theData.addDataObject(new TelevisionSeries(lastClick_X,lastClick_Y) );
    }
    
    public void doNewTVEpisode() 
    { 
       theData.addDataObject(new TVEpisode(lastClick_X,lastClick_Y) );
    }

    public void addLink()
    {
        theData.startNewLink(lastClick_X, lastClick_Y);
    }
    
    
    //
    // This method makes the assumption that the popup invoker is a View
    //
    public void editObject()
    {
        //send message to current invoker of popUP        
        View currentView = (View)lastSentPopup.getInvoker();
        if( currentView == null)
        {
            Log.out("null display, editObject method in AllusionsDataModel failed...");
            return;
        }
        

        allusionDataObject theObject = (allusionDataObject)theData.getDataObject(lastClick_X,lastClick_Y);

        currentView.editObject( new AllusionEditPanel( theObject ) );
    }



    public EditPanel getEditPanel( dataObject theObject)
    {
        return (EditPanel)(new AllusionEditPanel( theObject ) );
    }



    public dataObject getDataObject(int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList =  dataManager.getDataManager().getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            if ( tempObject.pointInsideObject(x,y) )
                return tempObject;
        }       
        
        return null;
    }

}
