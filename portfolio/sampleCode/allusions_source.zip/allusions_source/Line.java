//
//  Line.java
//  allusionsApp
//
//  Created by Matthieu Cormier on Tue May 27 2003.
//

import java.awt.*;

public class Line extends Object
{
	public int X0, Y0;
	public int X1, Y1;
	public int Yintercept;
	public float Slope;
	
        
	Line ( Point start, Point end )
	{
		X0 = start.x;
		Y0 = start.y;
		X1 = end.x;
		Y1 = end.y;
		
		calculateSlope();
		calculateYIntercept();
	}
	
        Line ( int startX, int startY, int endX, int endY )
        {
            this( new Point(startX,startY), new Point(endX,endY) );
        }
        
	private void calculateYIntercept()
	{
		Yintercept = (int)(Y0 - (Slope * X0));
	}
	
	private void calculateSlope()
	{
		int DeltaX, DeltaY;
	
		DeltaX = X1 - X0;
		DeltaY = Y1 - Y0;
		
		Slope = (float)DeltaY / DeltaX;	/*Find slope of the line		y = [m]x + b */
	}
	
	public void setStartPoint( Point start ) 
	{ 
		X0 = start.x;
		Y0 = start.y;
		
		calculateSlope();	
		calculateYIntercept();	
	}

	public void setEndPoint( Point end ) 
	{ 
		X1 = end.x;
		Y1 = end.y;
		
		calculateSlope();
		calculateYIntercept();
	}
	
	public Line getPerpendicularLine(Point start, float width)
	{
		float perpSlope = -Slope;
		float perpYIntercept = -(start.x * perpSlope) + start.y;
		float theta = (float)Math.atan( perpSlope ); 
		
		int yDistance = (int) (Math.cos(theta) * (width / 2));		
		int xDistance = (int) (Math.sin(theta) * (width / 2));				

		Point perpEnd   = new Point(0,0);
		Point perpStart = new Point(0,0);


		if(X0 <= X1)
		{
			perpStart.x = start.x + xDistance;
			perpStart.y = start.y + yDistance;
			perpEnd.x = start.x - xDistance;
			perpEnd.y = start.y - yDistance;
		}
		else
		{
			perpStart.x = start.x - xDistance;
			perpStart.y = start.y - yDistance;
			perpEnd.x = start.x + xDistance;
			perpEnd.y = start.y + yDistance;
		
		}
		
	
		return new Line(perpStart,perpEnd);
	}
		
	public int calculateY( int X )
	{
            //y = mx + b
            return Math.round((Slope * X) + Yintercept);
	}

	public int calculateY( float X )
	{
            //y = mx + b
            return (int)( (Slope * X) + Yintercept);
	}


	public int calculateX( int Y )
	{
            //x = (y - b)/x
            return (int)( (Y - Yintercept) / Slope );
	}

	public int calculateX( float Y )
	{
             //x = (y - b)/x
            return (int)( (Y - Yintercept) / Slope );
	}
	
	

        
	
	public void println( String toPrint)
	{
		System.out.println(toPrint);
	}
	


    //optimize if necessary later
    public Point getIntersectionPointfromRect(Rectangle rect)
    {
        //test TOP of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY(),  
                                                rect.getX() + rect.getWidth(), rect.getY() ) )
        {
            return new Point( calculateX((int)rect.getY()), (int)rect.getY() );
        }
        
        //test RIGHT side of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX() + rect.getWidth(), rect.getY(),  
                                                rect.getX() + rect.getWidth(), rect.getY() + rect.getHeight() ) )
        {
            return new Point( (int)(rect.getX() + rect.getWidth()), calculateY((int)(rect.getX() + rect.getWidth())) );
        }

        //test LEFT side of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY(),  
                                                rect.getX(), rect.getY() + rect.getHeight() ) )
        {
            return new Point( (int)(rect.getX()), calculateY((int)(rect.getX())) );
        }

        //test BOTTOM of Rect
        if( java.awt.geom.Line2D.linesIntersect(X0, Y0, X1, Y1,
                                                rect.getX(), rect.getY()  + rect.getHeight(),  
                                                rect.getX() + rect.getWidth(), rect.getY()  + rect.getHeight() ) )
        {
            return new Point( calculateX((int)(rect.getY()  + rect.getHeight()) ), (int)(rect.getY() + rect.getHeight() ) );
        }
      
        return null;
    }



    
	
	public String toString()
	{
		return ("Y = " + Slope + "X + " + Yintercept + "  Range (X0,Y0) (" + X0 + "," + Y0 + ") - (X1,Y1) (" + X1 + "," + Y1 + ")");
	}

}