/*
 *  SplitGraphPropertiesView.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Sun Jun 15 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.util.*;

public class SplitGraphPropertiesView extends View
{
    private dataManager 		theData;
    
    private AllusionGraphView 		graphPane;
    private JPanel			emptyEditPane;
    
    private dataObject 			_lastObject;
    
    public JSplitPane			splitPane;


    public SplitGraphPropertiesView( dataManager theDataManager )
    {
        theData = theDataManager;
    
        setBackground( java.awt.Color.white  );

        graphPane = new AllusionGraphView(theData);
        graphPane.setParent(this);
        
        // attach this view to the dataManager so it will be notified
        // when there are changes to the data
        theData.attach(this);
        
        emptyEditPane = new JPanel();
        
        Dimension minimumSize = new Dimension(100, 50);
        emptyEditPane.setMinimumSize(minimumSize);  
        graphPane.setMinimumSize(minimumSize);  
        
         //
        //Put the graph view in a scroll pane
        //
        JScrollPane scrollPane = new JScrollPane(graphPane);
        //
        // Mac OS UI guidelines state scrollbars should always be there
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
      
                                                
        splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,scrollPane, emptyEditPane );
        splitPane.setOneTouchExpandable(true);
        
        splitPane.setDividerLocation(400);
        
        
        splitPane.setPreferredSize(new Dimension(640, 480));
        
        

  
        

        //Provide a preferred size for the split pane
        splitPane.setPreferredSize(new Dimension(400, 200));      
        splitPane.setVisible(true);
    
        add(splitPane);
        
    }

    public void editObject(EditPanel editPanel)
    {
        //splitPane.setBottomComponent(editPanel);
        update();
    }
    
    
 
    public void update()
    {
        dataObject tempObject;
        
        int dividerLocation = splitPane.getDividerLocation(); //save divider location
        
        // object properties should only be shown if 1 object is selected
        if ( theData.getNumSelectedItems() == 1 )
        {
            Enumeration dataList = theData.getSelectedData();
            
            tempObject = (dataObject)dataList.nextElement();            
 
            // Create a new edit panel only if we're dealing with a new object
            if( tempObject != _lastObject)
            {
                EditPanel editPanel = theData.getEditPanel(tempObject);
                
                splitPane.setBottomComponent(editPanel);
                splitPane.setDividerLocation(dividerLocation);
                
                _lastObject = tempObject;
            }
            
            
        } else {
            //
            if( splitPane.getBottomComponent() != emptyEditPane )
            {
                _lastObject = null;
                
                splitPane.setBottomComponent( emptyEditPane );
                splitPane.setDividerLocation(dividerLocation);
            }
        }
        
        
    }
    

    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    public void paint(Graphics g) { super.paint(g); }

 
}
