/*
 *  ApplicationPreferences.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Thu Jun 26 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */




// Implements the singleton pattern

import org.argouml.configuration.*;
import simple.logging.Log;

import java.awt.*;
import java.util.*;
import java.io.*;
import javax.swing.*;

public class ApplicationPreferences 
{
  
    public static final ConfigurationKey KEY_WINDOW_TOP_Y = Configuration.makeKey("window", "top");

    public static final ConfigurationKey KEY_WINDOW_LEFT_X = Configuration.makeKey("window", "left");

    public static final ConfigurationKey KEY_WINDOW_WIDTH = Configuration.makeKey("window", "width");

    public static final ConfigurationKey KEY_WINDOW_HEIGHT = Configuration.makeKey("window", "height");

    public static final ConfigurationKey KEY_LAST_VIEW = Configuration.makeKey("last", "view");

    public static final ConfigurationKey KEY_LAST_SAVE_DIR = Configuration.makeKey("last", "save", "dir");
   
    public static final ConfigurationKey KEY_LAST_OPEN_DIR = Configuration.makeKey("last", "open", "dir");

    private ConfigurationHandler _config;
  
    private static ApplicationPreferences SINGLETON = new ApplicationPreferences();





    //---------------------------------------------------------------
    // Private constructor so it cannot be instantiated.
    //---------------------------------------------------------------
    private ApplicationPreferences()
    {
        _config = ConfigurationFactory.getInstance().getConfigurationHandler();
        _config.loadDefault();
    }
    
    
    
    
    
    //---------------------------------------------------------------   
    // Returns the instance of the ApplicationPreferences singleton.  
    //---------------------------------------------------------------     
    public static ApplicationPreferences getPreferences()
    {
        return SINGLETON;
    }
 
 
 
 
    //--------------------------------------------------------------- 
    // Sets the main window to its previous location and size
    //---------------------------------------------------------------    
    public void loadPreferences( allusionsApp theApp )
    {
    
        String YPosition = _config.getValue(KEY_WINDOW_TOP_Y.getKey(), "Guvaba");
        String XPosition = _config.getValue(KEY_WINDOW_LEFT_X.getKey(), "Guvaba");
        
        String winWidth  = _config.getValue(KEY_WINDOW_WIDTH.getKey(), "640");
        String winHeight = _config.getValue(KEY_WINDOW_HEIGHT.getKey(), "480");

        //Set window location
        try
        {
            java.lang.Integer X = new Integer( XPosition );
            java.lang.Integer Y = new Integer( YPosition );                    
            
            Point topLeftCorner = new Point(  X.intValue(),  Y.intValue() );
            theApp.setLocation(topLeftCorner);
        }
        catch ( NumberFormatException excep)
        {
            Log.out("Properties for window position not found");
        }
       
       
       
        //set window size
        try
        {
            java.lang.Integer height = new Integer ( winHeight );
            java.lang.Integer width  = new Integer ( winWidth  );
            
            theApp.setSize(width.intValue(),height.intValue());
        }
        catch ( NumberFormatException excep)
        {
            Log.out("Error setting window size");
        }
 
             
        //load last directory save and open locations
        theApp.lastSaveDir = _config.getValue(KEY_LAST_SAVE_DIR.getKey(), _config.getDefaultPath() );                                     
        theApp.lastOpenDir = _config.getValue(KEY_LAST_OPEN_DIR.getKey(), _config.getDefaultPath() );                                     
                        
        loadPreferences(theApp.getViewManager());
    }
    
    
    
    
    
    //---------------------------------------------------------------    
    // Saves the main window's location and size
    //---------------------------------------------------------------    
    public void savePreferences( allusionsApp theApp )
    {    
        //create a new properties file if one does not exist
        boolean force = true;
        
        //save window location
        _config.setValue(KEY_WINDOW_TOP_Y.getKey(), theApp.getY() + "" );
        _config.setValue(KEY_WINDOW_LEFT_X.getKey(), theApp.getX() + "");
        
        //save window size
        Dimension windowSize = theApp.getSize();
        _config.setValue(KEY_WINDOW_WIDTH.getKey(),  (int)windowSize.getWidth() + "" );
        _config.setValue(KEY_WINDOW_HEIGHT.getKey(), (int)windowSize.getHeight() + "" );
        
        //save last directory save and open locations
        _config.setValue(KEY_LAST_SAVE_DIR.getKey(), theApp.lastSaveDir );
        _config.setValue(KEY_LAST_OPEN_DIR.getKey(), theApp.lastOpenDir );
       
        savePreferences(theApp.getViewManager());
        
        _config.saveDefault(force);
            
    }
 
    //--------------------------------------------------------------- 
    // Sets the view the user was last using
    //---------------------------------------------------------------    
    private void loadPreferences( ViewManager viewManager )
    {
        String lastView = _config.getValue(KEY_LAST_VIEW.getKey(), "Guvaba");
        
        viewManager.setView(lastView);
    }
    
    //---------------------------------------------------------------    
    // Saves the view the user was last using
    //---------------------------------------------------------------    
    private void savePreferences( ViewManager viewManager )
    {
        String lastView = viewManager.getView();
        
        _config.setValue(KEY_LAST_VIEW.getKey(), lastView);        
    }
}
