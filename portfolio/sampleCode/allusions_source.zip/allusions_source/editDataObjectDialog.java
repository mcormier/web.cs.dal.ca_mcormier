/**
*  editDataObjectDialog.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Mon May 12 2003.
*
*
*
* @deprecated 	This class has been replaced by AllusionEditPanel
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class editDataObjectDialog extends JDialog
                                  implements ActionListener
{
   private dataObject theData;
    private Frame parent;
    
    private JTextField titleField;
    private JTextField authorField;
    private JButton cancelButton;
    private JButton applyButton;
    
    private GridBagLayout layout;
    private GridBagConstraints c;
    
    private boolean dataModified;
    
    protected static String CANCEL_CHOSEN = "chose_cancel";
    protected static String APPLY_CHOSEN = "chose_apply";
    
    protected static String MOVIE = movieDataObject.objectType;
    protected static String BOOK = bookDataObject.objectType;
    
    public editDataObjectDialog( Frame owner, dataObject data)
    {
/*     
        super(owner, "", true);  //true is for modal
        
        theData = data; 	//should check for null data
        dataModified = false;
        
        //Layout manager stuff
        layout = new GridBagLayout();
        getContentPane().setLayout(layout);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10,5,5,5);  //padding

        c.weightx = 0.5;

        setResizable(false);
        setSize(200,200);
 
        addDataFields();
        addButtons();
*/
    }
    
    public boolean isDataModified() { return dataModified; }
    
    private void addDataFields()
    {
  /* 
        String dataType = theData.getDataObjectType();

        if(dataType.equals( MOVIE ) )
        {
            setTitle("Edit Movie");
            createMovieForm();
        }
  
        if(dataType.equals( BOOK ) )
        {
            setTitle("Edit Book");
            createBookForm();
        }
  */      
    }
    
    private void createMovieForm()
    {
/*     
        movieDataObject movieObject = (movieDataObject)theData;

        JLabel titleLabel = new JLabel("Title: ");
        
        titleField = new JTextField(movieObject.getTitle());
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        getContentPane().add(titleLabel);

        c.gridx = 2;
        layout.setConstraints(titleField, c);
        getContentPane().add(titleField);
        
   
   */    
    }
    
    private void createBookForm()
    {
/* 
        bookDataObject bookObject = (bookDataObject)theData;
  
        JLabel titleLabel = new JLabel("Title: ");
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        

        c.weightx = 0.5;
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        getContentPane().add(titleLabel);

        titleField = new JTextField(bookObject.getTitle());
        c.gridx = 2;
        layout.setConstraints(titleField, c);
        getContentPane().add(titleField);
        
     
        JLabel authorLabel = new JLabel("Author: ");
        authorLabel.setHorizontalAlignment(JLabel.RIGHT);
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(authorLabel, c);
        getContentPane().add(authorLabel);

        authorField = new JTextField(bookObject.getAuthor());
        c.gridx = 2;
        layout.setConstraints(authorField, c);
        getContentPane().add(authorField);
   */           
    }
    
    private void addButtons()
    {
/*     
        JButton cancelButton = new JButton("Cancel");
        JButton applyButton = new JButton("Apply");
        
        c.anchor = GridBagConstraints.SOUTH; //bottom of space
        
        c.weighty = 1.0; 
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(cancelButton, c);
        
        cancelButton.setActionCommand(CANCEL_CHOSEN);
        cancelButton.addActionListener(this);
        getContentPane().add(cancelButton);
        
        
        c.gridx = 2;
        layout.setConstraints(applyButton, c);
        
        applyButton.setActionCommand(APPLY_CHOSEN);
        applyButton.addActionListener(this);
        getContentPane().add(applyButton);
    
*/
    
    }
    
    //Handle action events from all the buttons.
    public void actionPerformed(ActionEvent e) 
    {
/* 
        String command = e.getActionCommand();

        if (CANCEL_CHOSEN.equals(command)) 
            cancelChosen();
        
        if (APPLY_CHOSEN.equals(command)) 
            applyChosen();

*/
    }
    
    private void cancelChosen()
    {
  //      this.hide();
    }

    private void applyChosen()
    {
/* 
        String dataType = theData.getDataObjectType();
       
        //save data back to data object
        if(dataType.equals( MOVIE ) )
            saveMovieData();
  
        if(dataType.equals( BOOK ) )
            saveBookData();
        
        this.hide();
        dataModified = true;
*/
    }
    
    private void  saveMovieData()
    {
//        movieDataObject movieObject = (movieDataObject)theData;
        
//        movieObject.setTitle (titleField.getText());
    }
    
    private void saveBookData()
    {
//        bookDataObject bookObject = (bookDataObject)theData;
        
//        bookObject.setTitle(titleField.getText());
//        bookObject.setAuthor(authorField.getText());
    }
    
    //---------------------------------------------------------------
    // Debugging methods
    //---------------------------------------------------------------
    protected void println(String toPrint)
    {
//    	System.out.println(toPrint);
    }

}
