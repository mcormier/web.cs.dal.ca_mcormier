/*
 *  ViewManager.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Tue Jun 17 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ResourceBundle;
import java.util.Locale;
import java.util.Hashtable;

public class ViewManager implements ActionListener
{

    // Store the views in a Panel with a cardlayout
    private JPanel cards;

    // Store menu item strings in a resource
    protected ResourceBundle resbundle;

    protected JMenuBar mainMenuBar;
    protected JMenu viewMenu;

    // Associating views with strings allows us to save
    // which view the user last used in a prefs file
    final static String GRAPHVIEW = "SimpleGraphView";
    final static String TREEVIEW  = "SimpleTreeView";
    final static String SPLITVIEW = "SimpleSplitView";

    // One menu item for each view
    protected JCheckBoxMenuItem miGraphView;
    protected JCheckBoxMenuItem miTreeView;
    protected JCheckBoxMenuItem miSplitView;

    // and finally the views
    private View        graphView,
                        treeView,
                        splitView;

    // Two hashtables 
    // 		one for associating the string with the checkBoxMenuItem
    // 		and one for actual view
    //
    private Hashtable 	menuItemHash,
                        viewHash;

    // Store the current view menu item
    // enures that only one menu item is checked
    // at a time
    protected JCheckBoxMenuItem miCurrentView;
    protected String		currentViewString;

    private Container contentPane;

    private dataManager theDataManager;
    private AllusionsDataModel   theDataModel;




    public ViewManager(Container content, JMenuBar theMainMenuBar)
    {
        contentPane = content;
        mainMenuBar = theMainMenuBar;
        cards = new JPanel();
        cards.setLayout(new CardLayout());
        
        //create out dataModel
        theDataModel = new AllusionsDataModel();
        theDataManager = dataManager.getDataManager();
        theDataManager.initialize(theDataModel);

        resbundle = ResourceBundle.getBundle ("allusionsAppstrings", Locale.getDefault());        
        viewMenu = new JMenu(resbundle.getString("viewMenu"));
        
        createGraphView();
        //createTreeView();
        createSplitView();
        
        createHashes();
        
        //get this view from preferences
        setView(SPLITVIEW);
        
        contentPane.add(cards, BorderLayout.CENTER);
        
        mainMenuBar.add(viewMenu);
    }
    
    private void createHashes()
    {
        menuItemHash 	= new Hashtable(2);
        viewHash 	= new Hashtable(2);

        menuItemHash.put(GRAPHVIEW,miGraphView);
        //menuItemHash.put(TREEVIEW,miTreeView);
        menuItemHash.put(SPLITVIEW,miSplitView);
        
        viewHash.put(GRAPHVIEW,graphView);
        //viewHash.put(TREEVIEW,treeView);
        viewHash.put(SPLITVIEW,splitView);
       

    }
    
    private void createGraphView()
    {
        graphView = new AllusionGraphView(theDataManager);
       
        //
        //Put the graph view in a scroll pane
        //
        JScrollPane scrollPane = new JScrollPane(graphView);
        //
        // Mac OS UI guidelines state scrollbars should always be there
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        
        cards.add(scrollPane, GRAPHVIEW);
        
        miGraphView = new JCheckBoxMenuItem (resbundle.getString("graphView"));
        viewMenu.add(miGraphView).setEnabled(true);
        miGraphView.setState(false);
        miGraphView.addActionListener(this);

    }
    
    private void createTreeView()
    {
        treeView = new TreeView(theDataManager);
        cards.add(treeView, TREEVIEW);
        
        miTreeView = new JCheckBoxMenuItem (resbundle.getString("treeView"));
        viewMenu.add(miTreeView).setEnabled(true);
        miTreeView.setState(false);
        miTreeView.addActionListener(this);
    }
    
    private void createSplitView()
    {
        splitView = new SplitGraphPropertiesView(theDataManager);
        //HACK create an accessor for splitpane
        
        SplitGraphPropertiesView temp = (SplitGraphPropertiesView)splitView;
        
        cards.add( temp.splitPane,SPLITVIEW);

        miSplitView = new JCheckBoxMenuItem (resbundle.getString("splitView"));
        viewMenu.add(miSplitView).setEnabled(true);
        miSplitView.setState(false);
        miSplitView.addActionListener(this);
        
        
    }
    
    public boolean setView( String viewString )
    {
        JCheckBoxMenuItem newView;
        currentViewString = viewString;
        
        // get new menuItem
        newView = (JCheckBoxMenuItem)menuItemHash.get(viewString);
    
        //Do not set view if string does not exist in hash 
        if( newView == null)  return false;
    
        if( miCurrentView != null)
            miCurrentView.setState(false);
            
       
        newView.setState(true);
        miCurrentView = newView;
        
        CardLayout cl = (CardLayout)(cards.getLayout());
        cl.show(cards, viewString);
        
        return true;
    }
    
  
    public String getView() { return currentViewString; }

    // ActionListener interface (for menus)
    public void actionPerformed(ActionEvent newEvent) 
    {
        if (newEvent.getActionCommand().equals(miGraphView.getActionCommand())) setView(GRAPHVIEW);
        //else if (newEvent.getActionCommand().equals(miTreeView.getActionCommand())) setView(TREEVIEW);
        else if (newEvent.getActionCommand().equals(miSplitView.getActionCommand())) setView(SPLITVIEW);
                
    }

    
}
