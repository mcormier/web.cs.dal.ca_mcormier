/*
 *  Season.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Sun Jun 15 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.util.*;
import java.io.*;
import java.awt.*;
import simple.logging.Log;

public class Season extends allusionDataObject
                    implements Serializable, ScrollContainerObject
{

    public static String objectType = "season";

    private Vector episodes;
    private TelevisionSeries theParent;
    
    private int _seasonNumber;
    
    private ScrollContainer _scrollCont;

    private int _title_y_position;

    // A TV series can only have one series active at once this variable will be 
    // used in the future to draw the season differently so you can tell which one 
    // is active
    private boolean _active;

    public Season(TelevisionSeries parent) 
    {
        theParent = parent;
        episodes = new Vector();
        
        _scrollCont = new ScrollContainer( episodes );
        _seasonNumber = 1;
        title = new String("Season " + _seasonNumber );
        
        width = 70;
        height = 20;
        _active = false;
    }

    public String isA() { return Season.objectType; }
    
    public static boolean isA( dataObject theObject)
    {
        if (theObject == null) return false;
        
        String otherObjectType = theObject.isA();
        
        if( otherObjectType.equals( Season.objectType ) )
            return true;
            
        return false;
    }

    public void setNumber( int newNum ) 
    { 
        _seasonNumber = newNum; 
        title = new String("Season " + _seasonNumber );        
    }
    
    public int getNumber() { return _seasonNumber; }

    public int getHeight() { return height; }
    
    public void addEpisode( TVEpisode anEpisode)
    {
        episodes.addElement( anEpisode );
        
        anEpisode.attachtoSeries(this);
    }

    public void removeEpisode( TVEpisode anEpisode)
    {
        episodes.removeElement( anEpisode );
    }

    public int numberOfEpisodes(){ return episodes.size(); }
    
    public void paintNotSelected( Graphics g )
    {
       /* g.setColor(java.awt.Color.orange );   
        g.fillRect( x, y,width,height);           

        g.setColor(java.awt.Color.black ); 
        
        String title = new String("Season X");
        
        int temp = (x+ (width/2) ) - (title.length()/2) * _fontsize;
        g.drawString(title, temp, y+(height/2));*/

    }
    
    public void paint( Graphics g)
    {
        /*if( !_isAttachedToSeries )
        {
            super.paint(g);
        }*/

    }

    protected void _calculateTitlePosition()
    {
         if( _savedMetrics != null )
        {
            int stringWidth = _savedMetrics.stringWidth( title );

            _title_X_RelativePosition = (getWidth() /2) - (stringWidth/2);
            _title_Y_RelativePosition = ( getHeight() + _savedMetrics.getMaxAscent() )/2;
        }
   
    }

    
    public void paint( Graphics g, int X, int Y)
    {
        if ( x != X || y != Y )
        {
            x = X;
            y = Y;
            
            _savedMetrics = g.getFontMetrics();
            _calculateTitlePosition();

            _title_y_position = y + (height/2);
        }
        
        

        //Inverse Text and Rect color if season is 
        // active
        if(_active)
            g.setColor(java.awt.Color.black );
        else
            g.setColor(java.awt.Color.orange );   
            
        g.fillRect( x, y,width,height);           

        if(_active)
             g.setColor(java.awt.Color.orange );
        else
            g.setColor(java.awt.Color.black ); 
        
        

        g.drawString(title, 
                     x + _title_X_RelativePosition, 
                     y + _title_Y_RelativePosition );
        
        if( selected )
        {
            g.setColor(java.awt.Color.black ); 
            g.drawRect( x, y, width,height);        
        }

    }
    
    public void paintEpisodes( Graphics g)
    {
        Point topLeftofSeries = theParent.getTopLeftCorner();
        int X = topLeftofSeries.x + theParent.width + width + (ScrollContainer.BORDER * 2);
        
        // Y position if season contains 1 episode
        int y = topLeftofSeries.y + (theParent.width/2);  
        
        _scrollCont.paint(g, X, y);
    
    }
    public void delete()
    {
        Enumeration dataList = episodes.elements();
      
        while( dataList.hasMoreElements() )
        {
            TVEpisode tempObject = (TVEpisode)dataList.nextElement();
            
            tempObject.delete();           
        }
        
    }
 
    public void navArrowClicked( int checkX, int checkY )
    {
         _scrollCont.navArrowClicked(checkX, checkY);
     }
 
    public void selectObject() 
    { 
        super.selectObject(); 
        theParent.setSelectedSeason(this);
    }

    public void setActive(boolean state)
    {
        _active = state;
        _scrollCont.setVisible(state);
    }
 
}
