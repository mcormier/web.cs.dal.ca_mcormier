/**
*  allusionWorkSpacePanel.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Sun Apr 27 2003.
*
*
* @deprecated 	This class has been replaced by ViewManager
*/

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class allusionWorkSpacePanel extends JPanel
                                    implements MouseListener, MouseMotionListener, KeyListener
{

    public JFrame parentFrame;

    private dataManager theDataManager;
    private AllusionsDataModel   theDataModel;

    private View        currentView,
                        graphView,
                        treeView,
                        splitGraphPropView;
    

    
    private CardLayout layout;
    
    public allusionWorkSpacePanel() 
    {
       /* super();
        setOpaque(true);
        setBackground( new java.awt.Color(255,255,255) );
        layout = new CardLayout();
        setLayout(layout);
        
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        
        //for some reason this line activates the key listener
        //and then all keys can be captured in the key listener methods
        getInputMap().put(KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_BACK_SPACE,0), "doSomething");
       
        theDataModel = new AllusionsDataModel();
        theDataManager = new dataManager(theDataModel);
        
        
        //graphView = new GraphView(theDataManager,this);
        //treeView  = new TreeView(theDataManager, this);
        
        //splitGraphPropView = new SplitGraphPropertiesView(theDataManager, this);
        //setSplitView();
        //setGraphView();
        //setTreeView();
        //currentView = graphView;
        layout.addLayoutComponent (graphView,"graph");
        layout.show(this, "graph");*/
    }


    public void setParent(JFrame theParent)
    {
        parentFrame = theParent;
    }
 
    
          
     //---------------------------------------------------------------
    // Mouse listener methods
    //---------------------------------------------------------------

    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e)  {}
    
    public void mouseClicked(MouseEvent e) { /*currentView.mouseClicked(e);*/ }
    public void mousePressed(MouseEvent e) { /*currentView.mousePressed(e);*/ }
    public void mouseReleased(MouseEvent e) { /*currentView.mouseReleased(e);*/ }

     //---------------------------------------------------------------
    // Mouse Motion listener methods
    //---------------------------------------------------------------
 
    public void mouseDragged(MouseEvent e) { /*currentView.mouseDragged(e);*/ }
    public void mouseMoved(MouseEvent e )  { /*currentView.mouseMoved(e);*/   }

     //---------------------------------------------------------------
    // Key listener methods
    //---------------------------------------------------------------
    public void keyPressed(KeyEvent e) { /*currentView.keyPressed(e);*/ }
    public void keyReleased(KeyEvent e){ /*currentView.keyReleased(e);*/ }     
    public void keyTyped(KeyEvent e) { }
    
        
    //---------------------------------------------------------------
    //	Painting methods
    //---------------------------------------------------------------
    public void paint(Graphics g)
    {
        super.paint(g);
        //currentView.paint(g);
    }
          
    public void update(Graphics g)
    {
        paint(g);
    }
  
    
    //---------------------------------------------------------------
    // View methods
    //---------------------------------------------------------------
    public void setGraphView()
    {
        changeView( graphView );
    }
    
    public void setTreeView()
    {
        changeView( treeView );
    }
    
    public void setSplitView()
    {
        changeView( splitGraphPropView );
    }
     
    public View getCurrentView() { return currentView; }
                 
    private void changeView( View newView)
    {
        /*if( currentView != null)
            currentView.deActivate();
            
        currentView = newView;
        currentView.activate();
        repaint();*/
    }
    //---------------------------------------------------------------
    // Debugging methods
    //---------------------------------------------------------------
    private void println(String toPrint)
    {
    	System.out.println(toPrint);
    }
    
}
