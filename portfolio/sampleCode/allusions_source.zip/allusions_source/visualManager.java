/**
*  visualManager.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Mon May 19 2003.
*
*
* @deprecated 	This class has been renamed to View
*/
import java.awt.*;
import java.awt.event.*;

public abstract class visualManager
{

    abstract void update();

    //---------------------------------------------------------------
    // Mouse listener methods
    //---------------------------------------------------------------
    abstract void mouseClicked(MouseEvent e);
    abstract void mousePressed(MouseEvent e);
    abstract void mouseReleased(MouseEvent e);
     //---------------------------------------------------------------
    // Mouse Motion listener methods
    //---------------------------------------------------------------
    abstract void mouseDragged(MouseEvent e);
    abstract void mouseMoved(MouseEvent e );
  
    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    abstract void paint(Graphics g);

     //---------------------------------------------------------------
    // Key listener methods
    //---------------------------------------------------------------
    abstract void keyPressed(KeyEvent e);
    abstract void keyReleased(KeyEvent e);

    //If a visual manager adds components such as Buttons they should be
    //added to the display when setActive is called and removed from the
    //display when deactivate is called
    abstract void activate();
    abstract void deActivate();
    
    
    //---------------------------------------------------------------
    // Debugging methods
    //---------------------------------------------------------------
    protected void println(String toPrint)
    {
    	System.out.println(toPrint);
    }

}
