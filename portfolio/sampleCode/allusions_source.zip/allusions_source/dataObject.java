/*
 *  dataObject.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Wed Apr 30 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.geom.*;

import java.io.*;

public abstract class dataObject
                      implements Serializable
{
 
    protected static String objectType;
    protected int x, y;				//objects top left corner position
    protected int dragDistX, dragDistY;		//used for dragging, distance of mouse from top left corner
    protected int width = 50;			//size of box
    protected int height = width;

    protected Vector pointsTo;
    protected Vector pointedFrom;

    protected boolean selected;
    protected boolean isVisible;
    
    abstract void paint( Graphics g );
    abstract void paintNotSelected( Graphics g);
    abstract void paintSelected( Graphics g);

    abstract String isA();
    
    public dataObject()
    {
        pointsTo = new Vector();
        pointedFrom = new Vector();
        selected = false;
        isVisible = true;
    }
    
    public boolean objectSelected() { return selected; }
    public void selectObject() { selected = true; }
    public void deSelectObject() { selected = false; }
    
    public int getWidth() { return width; }
    
    public int getHeight() { return height; }
    
    public void setVisible( boolean state) { isVisible = state; }
    public boolean isVisible() { return isVisible; }
    
    public Point getTopLeftCorner() { return (new Point(x,y)); }
    
    public boolean pointInsideObject( int checkX, int checkY)
    {
        if( !isVisible) return false;
    
        if( checkX >= x && checkX <= ( x + width) && checkY >= y && checkY <= ( y + height) )
                return true;
        
        return false;
    }
    
    public boolean objInsideBox(int checkX, int checkY, int boxWidth, int boxHeight)
    {
            int tempX = checkX; 
            int tempY = checkY;
            
            if( !isVisible) return false;
            
            //Handle negative heights or widths
            if ( boxHeight < 0 ) 
                tempY = checkY + boxHeight; 
            if ( boxWidth < 0 ) 
                tempX = checkX + boxWidth;
 
            if( tempX < (x + width) && (tempX + Math.abs(boxWidth))  > x
                && tempY < (y + width) && (tempY + Math.abs(boxHeight)) > y)
                return true;
    
        return false;
    }
    
    public Point getCenter() { return ( new Point( x + (width/2) , y + (width/2) ) ); }
   
    public void addPointsToLink(dataLink theLink)
    {
        pointsTo.addElement(theLink);
    } 
 
    public void addPointedFromLink(dataLink theLink)
    {
        pointedFrom.addElement(theLink);
    } 
    
    public void removePointsToLink(dataLink theLink)
    {
         pointsTo.removeElement(theLink);
    }

    public void removePointedFromLink(dataLink theLink)
    {
         pointedFrom.removeElement(theLink);
    }
    
    public Enumeration getOutLinkData() { return pointsTo.elements(); }
    
    public int getOutLinkNumber() { return pointsTo.size(); }
 
    //public Enumeration getPointsFromData() { return pointsTo.elements(); }
       
    public void paintLinks( Graphics g)
    {
        dataLink tempObject;
        Enumeration dataList = pointsTo.elements();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataLink)dataList.nextElement();  
            
            tempObject.paint(g);    
        }
    }
          
    public void delete()
    {        
        dataLink tempLink;
        
        //remove pointed from links
        Enumeration dataList = pointsTo.elements();
        
        while( dataList.hasMoreElements() )
        {
            tempLink = (dataLink)dataList.nextElement();
            tempLink.getPointee().removePointedFromLink(tempLink);
        }
        
        
        //remove pointed from links
        dataList = pointedFrom.elements();
        
        while( dataList.hasMoreElements() )
        {
            tempLink = (dataLink)dataList.nextElement();
            tempLink.getPointer().removePointsToLink(tempLink);
        }
    }
    
    public Rectangle getObjectRect() { return new Rectangle( x, y, getWidth(), getHeight() ); }
    
}
