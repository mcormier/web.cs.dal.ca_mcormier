/*
 *  Log.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Fri Jun 27 2003.
 *
 *	$Id: Log.java,v 1.9 2003/09/07 23:15:00 joeshortsleeve Exp $
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

// This is a utility class for debugging
//
// It removes the need to type "System.out.println" which is rather long
// and replaces it with "Log.out" which is a little shorter and much more
// fun to type
//
//
// For more advanced logging options you are advised to investigate log4j
//
//	http://jakarta.apache.org/log4j/docs/index.html

package simple.logging;

public class Log 
{

    private static int lineNumber = 0;

    private static boolean turnedOn = true;

    //do not allow instantiation of this class
    private Log(){}

    public static void turnOn() { turnedOn = true; }
    
    public static void turnOff() { turnedOn = false; }

    public static void out(String toPrint)
    {
        if( !Log.turnedOn ) return;
        
        lineNumber++;
        System.out.println(lineNumber + " " + toPrint);
    }

}
