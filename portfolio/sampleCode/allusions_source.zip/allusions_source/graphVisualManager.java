/**
*  graphVisualManager.java
*  allusionsApp
*
*  Created by Matthieu Cormier on Wed May 14 2003.
*
*
* @deprecated 	This class has been renamed to GraphView
*/
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

public class graphVisualManager extends visualManager
{
    private dataManager theData;
    private allusionWorkSpacePanel 	theDisplay;

    private boolean drawSelectionBox, dragSelected, holdingShift;

    private int selectBox_X, selectBox_Y,
                lastClick_X, lastClick_Y,
                selectBox_width, selectBox_height,
                currentMouseX, currentMouseY;

    private JPopupMenu tempPopup;



    public graphVisualManager( dataManager theDataManager, allusionWorkSpacePanel display )
    {
       /*theData = theDataManager;
        //theData.attach(this);
        theDisplay = display;*/
    }
    
    public void activate() {}
    public void deActivate() {}
          
     //---------------------------------------------------------------
    // Mouse listener methods
    //---------------------------------------------------------------
    public void mouseClicked(MouseEvent e) 
    {
  /*       if( theData.creatingNewLink() )
        {
            //create link if valid
        }
        
        //drawLink = false;
    
        if( e.getClickCount() == 1 )
        {
            theData.selectDataObject( e.getX() , e.getY(), holdingShift );
            theDisplay.repaint();
            dragSelected = false;
        }*/
    }
    
     public void mousePressed(MouseEvent e)  
    { 
  /*      if( theData.creatingNewLink() )
        {
            //create link if valid
            theData.finishNewLink( e.getX() , e.getY() );
               
         }

        //drawLink = false;

        if( maybeShowPopup(e) ) {}
        else
        {
            if( theData.selectDataObject( e.getX() , e.getY(), holdingShift ) )
                      dragSelected = true;
            else //For drawing selection rectangle
            {
                drawSelectionBox = true;
                selectBox_X = e.getX();
                selectBox_Y = e.getY();
            }
            theDisplay.repaint();
        }*/
    }

    public void mouseReleased(MouseEvent e) 
    {
    /*    dragSelected = false; 
       
        selectBox_width = 0;
        selectBox_height = 0;
        drawSelectionBox = false;
        
        maybeShowPopup(e); 
        theDisplay.repaint();*/
    }


    private boolean maybeShowPopup(MouseEvent e) 
    {
/*
    	if (e.isPopupTrigger()) 
    	{
    		lastClick_X = e.getX();
    		lastClick_Y = e.getY();

                if( theData.isDataObject( e.getX(),  e.getY() ) )
                {
                    tempPopup = theData.getDataObjectPopup( e.getX(),  e.getY() );
                    tempPopup.setInvoker (theDisplay);
                    tempPopup.show(e.getComponent(), e.getX(), e.getY()); 
                }
                else
                {
                    tempPopup = theData.getDefaultPopup( e.getX(), e.getY() );
                    tempPopup.setInvoker (theDisplay);
                    tempPopup.show(e.getComponent(), e.getX(), e.getY()); 
                }
                
                return true;
        }
        */
        return false;
    }
    
    

     //---------------------------------------------------------------
    // Mouse Motion listener methods
    //---------------------------------------------------------------
 
    public void mouseDragged(MouseEvent e) 
    {
    /*    if(dragSelected)
        {
            theData.moveSelected(e.getX() , e.getY() );
            update();
            return;
        }
        
        if(drawSelectionBox)
        {
            selectBox_width = e.getX() - selectBox_X;
            selectBox_height = e.getY() - selectBox_Y;
            theData.multipleSelectBox( selectBox_X,selectBox_Y,selectBox_width,selectBox_height,holdingShift);
            update();
        }*/
        
    }
    
    public void mouseMoved(MouseEvent e ) 
    {
     /*        if( theData.creatingNewLink() )
        {
            currentMouseX = e.getX();
            currentMouseY = e.getY();
            update();
        }*/
    }
 


    public void update()
    {
       // theDisplay.repaint();
    }

    //---------------------------------------------------------------
    //
    //---------------------------------------------------------------
    public void paint(Graphics g)
    { 
    /*     
        if( theData.creatingNewLink() )
        {
            g.setColor( java.awt.Color.black );
            g.drawLine(lastClick_X,lastClick_Y,currentMouseX,currentMouseY);
        }

   
        paintData(g);

        if(drawSelectionBox)
        {
            g.setColor( java.awt.Color.black );
            int tempX = selectBox_X; 
            int tempY = selectBox_Y;
            
            //drawRect doesn't like negative heights or widths
            if ( selectBox_height < 0 ) 
                tempY = selectBox_Y + selectBox_height; 
            if ( selectBox_width < 0 ) 
                tempX = selectBox_X + selectBox_width;
            
            g.drawRect( tempX, tempY, Math.abs(selectBox_width), Math.abs(selectBox_height) );
            
        }
        */
     }


    protected void paintData( Graphics g)
    {
    /*     
        Point boxPoint;
        dataObject tempObject;

    
        g.setColor(new java.awt.Color(0,255,0) );

        //paint non selected objects 
        Enumeration dataList = theData.getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            tempObject.paint(g);
        }
        
        //paint selected objects last
        dataList = theData.getSelectedData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            tempObject.paintSelected(g);
        }


        //paint node links
        dataList = theData.getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            tempObject.paintLinks(g);
        }

*/
    }

    //
    // Move this dataModel specific code
    //
    public void editObject()
    {
    /*  
        dataObject theObjToEdit;
       
        theObjToEdit = theData.getDataObject(lastClick_X, lastClick_Y);
        
        if (theObjToEdit == null)
        {
            //println("No object to edit");
            return;
        }
        
        editDataObjectDialog editDialog = new editDataObjectDialog(theDisplay.parentFrame,theObjToEdit);

        editDialog.show();

        if(editDialog.isDataModified() )
            theDisplay.repaint();
            
        editDialog.dispose();
*/        
    }

     //---------------------------------------------------------------
    // Key listener methods
    //---------------------------------------------------------------
    public void keyPressed(KeyEvent e) 
    {
    /* 
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_BACK_SPACE )
        {
            theData.deleteSelected();
            theDisplay.repaint();
        }
        
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_SHIFT )
        {
            holdingShift = true;
        }
*/     
    }

    public void keyReleased(KeyEvent e) 
    { 
    /*     
        if( e.getKeyCode() == java.awt.event.KeyEvent.VK_SHIFT )
        {
            holdingShift = false;
        }
        */
    }


}
