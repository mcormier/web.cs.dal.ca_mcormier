/*
 *  TelevisionSeries.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Wed Jun 11 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.util.*;
import javax.swing.*;

import simple.logging.Log;
import org.tigris.gef.util.*;

public class TelevisionSeries  extends allusionDataObject 
{


    public static String objectType = "TelevisionSeries";

    public static int border = 5;    
    public static int NUM_SEASONS_SHOWN = 5;
    
    private String timeAired;
    
    private Vector seasons;

    private Season selectedSeason;

    private ScrollContainer _scrollCont;

    public static ImageIcon ICON_IMAGE;

    static 
    {
        // Load images           
        ICON_IMAGE = ResourceLoader.lookupIconResource(objectType);
    }


    public TelevisionSeries(int X, int Y)
    {
        super();
        x = X;
        y = Y;
        
        setTitle("TV series");
        timeAired = new String("");
        
        seasons = new Vector();
        
        
        _scrollCont = new ScrollContainer( seasons );
        _scrollCont.setRange(NUM_SEASONS_SHOWN);
    }



    public void addSeason( Season aSeason)
    {
        try
        {
            Season lastSeason = (Season)seasons.lastElement();
        
            aSeason.setNumber( lastSeason.getNumber() + 1 );
        }
        catch( NoSuchElementException nse)
        {
        }
        
        seasons.addElement( aSeason );
        setSelectedSeason(  aSeason );
        
        dataManager.getDataManager().addDataObject( aSeason );
    }


    public void addEpisode( TVEpisode theEpisode)
    {
        if( selectedSeason == null )
        {	
            if( seasons.size() < 1 )
                addSeason( new Season(this) );
            else
            {
                Season lastSeason = (Season)seasons.lastElement();
                setSelectedSeason( lastSeason );
            }
        }

        selectedSeason.addEpisode( theEpisode);
                   
    }


    public void removeEpisode( Season aSeason)
    {
        seasons.removeElement( aSeason );
    }


    public String isA() { return TelevisionSeries.objectType; }
 
    public static boolean isA( dataObject theObject)
    {
        if (theObject == null) return false;
        
        String otherObjectType = theObject.isA();
        
        if( otherObjectType.equals( TelevisionSeries.objectType ) )
            return true;
            
        return false;
    }

  
    public void paintNotSelected( Graphics g ) 
    {
        if( _savedMetrics == null || _savedMetrics != g.getFontMetrics() )
        {
            _savedMetrics = g.getFontMetrics();
            _calculateTitlePosition();
        }

        if ( ICON_IMAGE != null )
        {
            // Draw Icon
            ICON_IMAGE.paintIcon( null, g, x, y);
        }
        else
        {
            // Draw purple box
            g.setColor(java.awt.Color.magenta );   
            g.fillRect( x, y,width,width);           
        }
        
        // Draw bottom title label
        g.setColor( java.awt.Color.black );     
        g.drawString(title, x + _title_X_RelativePosition,
                            y + _title_Y_RelativePosition);
        
        paintLinks(g);
        
        _paintEpisodes(g);
        
        _paintSeasons(g);

       
    }

    private void _paintSeasons( Graphics g )
    {
        if( seasons.size() > 0 )
        {
    
            int X = this.x + width + border;
            int Y = y + (width/2);  
        
            _scrollCont.paint(g, X, Y);
        }
    }

    private void _paintEpisodes( Graphics g )
    {
        //Should only paint episodes of the active season
        if( selectedSeason != null )
        {
            if ( selectedSeason.numberOfEpisodes() > 0 )
            {
                selectedSeason.paintEpisodes(g); 
            }
        }
    }

    // timeAired get and set methods
    public String getAirTime() { return timeAired; };
    public void   setAirTime( String newString ) { timeAired = newString; }

    
    
    public void delete()
    {
        super.delete();
        
        //Call delete on all seasons
        selectedSeason.delete();
        
        //!!!!! Delete the seasons in the vector
    }
    
            
    public boolean pointInsideObject( int checkX, int checkY)
    {
        boolean mainObjectClicked = super.pointInsideObject( checkX, checkY);
    
        // Return true immediately if the main TVseries icon was clicked on        
        if( mainObjectClicked) return true;
        
        
        // Send message to season scroll container so that it check if
        // Navigation arrow was clicked
        _scrollCont.navArrowClicked( checkX, checkY );
        
        // Otherwise send message to active season so it can handle
        // Navigation arrow clicks
        if( selectedSeason != null )
            selectedSeason.navArrowClicked( checkX, checkY );
        
        return false;
    }
    
    public void setSelectedSeason( Season newSelection)
    {
        if(selectedSeason != null)
            selectedSeason.setActive(false);
    
        selectedSeason = newSelection;
        selectedSeason.setActive(true);
        
        dataManager.getDataManager().notifyViews();
    }
    
}
