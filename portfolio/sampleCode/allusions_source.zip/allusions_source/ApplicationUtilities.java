/*
 *  ApplicationUtilities.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Sat Aug 30 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import javax.swing.*;

public class ApplicationUtilities 
{

    private static boolean _isAqua;
    private static ApplicationUtilities SINGLETON = new ApplicationUtilities();

    public static boolean isAqua() { return _isAqua; }


    private void _checkForAqua()
    {
        // ------------- Sat Aug 30 2003 --------------------------------
        // http://developer.apple.com/technotes/tn/tn2042.html#Section0_1
        //
        // Detecting a Macintosh Client
        //
        // Some of the suggestions made in this Technical Note suggest that you make conditional 
        // API calls or placement of UI components.  The most common (and intuitive) method of 
        // finding out the operating system you are running on is checking the os.name System 
        // property.  This, however, involves correct parsing of the String-based result, which 
        // is subject to error, especially if Apple chooses to change the way this property is set.  
        // The more reliable (and simpler) means of finding out if your Java client is a Mac is by 
        // checking the mrj.version property:                  
        //
        // System.getProperty("mrj.version");                                  
        //
        // This property is set automatically by the JVM on all Mac OS X systems.  The test is simple:
        // if the returned String is not null, you're running on a Mac!  This is the method we 
        // recommend you employ if you need to confirm that you are running on a Macintosh.                  
        //
        // Additionally, many of the forthcoming suggestions are specific to Apple's Aqua interface.  
        // In other words, there are things you are enabling/disabling that you may not want to in 
        // the Java (Metal) or Motif look and feel's for Swing.  The best way to verify that Aqua is 
        // currently the active look and feel is to call                  
        //
        // UIManager.getSystemLookAndFeelClassName()                                  
        //
        // and compare the result to                                  
        //
        // UIManager.getLookAndFeel().getClass().getName()                                  
        //
        // Combined with the mrj.version check, this is an abstract and clean  way of finding out if 
        // you are using Aqua (first check if you're on a Mac, then check that the system look and 
        // feel is the same as the current running look and feel).  It doesn't require knowledge of 
        // the class name that Apple uses for its Aqua look and feel, and therefore guarantees that 
        // your logic will always work, even if Apple decides to change the name or package of the 
        // look and feel class.                                  
        //
        String testString = System.getProperty("mrj.version");
       
        if( testString != null &&
            UIManager.getSystemLookAndFeelClassName() == UIManager.getLookAndFeel().getClass().getName() )
        {
            _isAqua = true;
            _setMacProperties();
        }
        else
            _isAqua = false;
    }
    
    private void _setMacProperties()
    {
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        System.setProperty("com.apple.macos.useScreenMenuBar", "true");

        // ------------- Sun Aug 31 2003 --------------------------------
        // http://developer.apple.com/technotes/tn/tn2042.html#Section1_7
        //
        // File Dialogs in Aqua
        //        
        // Handling .pkg and .app files. Handling Mac OS X application bundles and installer 
        // packages inside your Java application is an additional concern.  Since a .app or a 
        // .pkg file is technically a directory, Java applications using  JFileChooser or 
        // FileDialog may initially recognize  them as such and allow inappropriate navigation.  
        // Apple has provided properties for both of these classes that can be used to control how 
        // .app bundles as  well as .pkg install packages (both actually directories) should be  handled.
        //
        // FileDialog.  The AWT FileDialog class can be set to treat .pkg and .app files as non-navigable 
        // using the system runtime property
        //
        // com.apple.macos.use-file-dialog-packages                                  
        //
        // Possible values are true (treats .pkg and .app as files) and false (as folders, the default 
        // behavior). The property can be set using the standard mechanisms for runtime system properties 
        // as explained in Tech Note 2031, and once set will be applied to all FileDialog instances.  This
        // allows for developers to alter their AWT dialogs for Aqua without any code change.  If your 
        // appliction requires different instances to behave differently, you can either set the property 
        // to true or false at runtime as necessary using System.setProperty(), or you can make use of 
        // the per-instance client properties in JFileChooser.      
                                    
         System.setProperty("com.apple.macos.use-file-dialog-packages", "true");
         System.setProperty("apple.awt.com.apple.macos.use-file-dialog-packages", "true");
         

        // http://developer.apple.com/documentation/Java/Reference/Java141SysProperties/System_Properties/chapter_1_section_3.html#//apple_ref/doc/uid/TP30000299/TPXREF110
        //
        // apple.awt.rendering
        //
        // Determines whether Graphics2D objects prioritize speed or quality. This option accepts either 
        // speed or quality for its value. It sets the KEY_RENDERING hint so that it accepts either 
        // VALUE_RENDER_SPEED or VALUE_RENDER_QUALITY as an argument. 
        System.setProperty("apple.awt.rendering", "VALUE_RENDER_SPEED");
        
        // http://developer.apple.com/technotes/tn/tn2031.html
        //
        // com.apple.macos.smallTabs
        //
        // If set to true, tabs will assume a smaller font size which in effect will shrink the overall 
        // size of each tab.  The Aqua HI Guidelines dictate that tabs should have two possible sizes
        System.setProperty("com.apple.macos.smallTabs", "true");
    }
    
    private ApplicationUtilities() 
    { 
        _checkForAqua(); 
    }

}
