/*
 *  AboutBox.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Fri Apr 25 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
import org.gjt.sp.jedit.gui.EnhancedDialog;
import org.tigris.gef.util.*;
import simple.logging.Log;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

//
//  This class leverages the EnhancedDialog class written in JEdit (version 4.1)
//  and is closely based on the AboutBox class in Jedit
//

public class AboutBox extends EnhancedDialog
                      implements ActionListener
{
    protected JButton closeButton;
   
    public AboutBox(JFrame parent) 
    {
        //use get version number HERE
        super(parent,"About Allusions",true);

        JPanel content = new JPanel(new BorderLayout());
        content.setBorder(new EmptyBorder(12,12,12,12));
        setContentPane(content);

        content.add(BorderLayout.CENTER,new AboutPanel());

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel,BoxLayout.X_AXIS));
        buttonPanel.setBorder(new EmptyBorder(12,0,0,0));

        buttonPanel.add(Box.createGlue());

        
        closeButton = new JButton("Close");
        closeButton.addActionListener(this);
        
        getRootPane().setDefaultButton(closeButton);
        buttonPanel.add(closeButton);
        buttonPanel.add(Box.createGlue());
        content.add(BorderLayout.SOUTH,buttonPanel);

        pack();
        setResizable(false);
        setLocationRelativeTo(parent);
        show();
    }
	
    public void actionPerformed(ActionEvent newEvent) 
    {
        dispose();
    }	
	
    public void ok()
    {
        dispose();
    } 


    public void cancel()
    {
        dispose();
    }
    
    static class AboutPanel extends JComponent
    {
        ImageIcon image;

        public static ImageIcon ABOUT_IMAGE;
        
        static 
        {
            // Load image           
            ABOUT_IMAGE = ResourceLoader.lookupIconResource("about");
        }

        AboutPanel()
        {
            setForeground(new Color(96,96,96));
            image = ABOUT_IMAGE;

            setBorder(new MatteBorder(1,1,1,1,Color.yellow));
        }

        public void paintComponent(Graphics g)
        {
            g.setColor(new Color(96,96,96));
            image.paintIcon(this,g,1,1);

        }

        public Dimension getPreferredSize()
        {
            return new Dimension(1 + image.getIconWidth(), 1 + image.getIconHeight());
        }

        public void addNotify()
        {
            super.addNotify();
        }

        public void removeNotify()
        {
            super.removeNotify();
        }

      }  // end of Aboutpanel

}