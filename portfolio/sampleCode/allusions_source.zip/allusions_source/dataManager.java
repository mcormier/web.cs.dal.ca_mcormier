/*
 *  dataManager.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Tue Apr 29 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;
import java.util.*;
import java.io.*;

import simple.logging.Log;

//
// A generic container for dataObjects
// Also manages selected dataObjects
//
// Contains a DataModel and passes any model specific
// operations to the DataModel
// (i.e. showing a relevant popup for an object)
// 
// Any Views that rely on a dataManager should attach themselves
// to the dataManger so they will be notified when changes are made
// to the data.
//
// Implements the singleton pattern
//
public class dataManager 
{    
    private static dataManager SINGLETON = new dataManager();

    //our dataObjects
    private Vector dataVector;
    
    //the current selected dataObjects [ always a subset of the dataVector]
    private Vector selectedObjVector;
    
    //Views that are attached to the dataManager and
    //should be notified when chages to the data are made
    private Vector associatedViews;
    
    // this variable is used for a datalink that is being created.  
    private dataLink tempLink;
    
    // Model specific functionality is passed to theModel
    // theModel will take care of things like creating 
    // EditPanels and Popup menus
    private DataModel theModel;

    //is a link currently in the middle of creation
    private boolean creatingNewLink;
    
    
    //---------------------------------------------------------------
    // Private constructor so it cannot be instantiated.
    //---------------------------------------------------------------
    private dataManager()
    {
	//initialize vectors
        dataVector = new Vector();
        selectedObjVector = new Vector();
        associatedViews = new Vector();
    
   }
    
    public void initialize(DataModel model)
    {
        //connect to model
        theModel = model;
        theModel.setDataManager(this);
 
    }

    
    //---------------------------------------------------------------   
    // Returns the instance of the ApplicationPreferences singleton.  
    //---------------------------------------------------------------     
    public static dataManager getDataManager()
    {
        return SINGLETON;
    }


    //---------------------------------------------------------------
    // - removes all current selected dataObjects from dataVector 
    // - clears selectedObjVector
    //---------------------------------------------------------------
    public void deleteSelected()
    {
        dataObject tempObject;
        Enumeration dataList = getSelectedData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            dataVector.removeElement(tempObject);
            tempObject.delete();
        }
        
        deSelectObjects();
    }
    
    public Enumeration getData() { return dataVector.elements(); }

    public Enumeration getSelectedData() { return selectedObjVector.elements(); }
    
    public int getNumSelectedItems() { return selectedObjVector.size(); }
    
    
    //---------------------------------------------------------------
    // - linearly queries each dataObject with given coordinates 
    // - returns true for the first object found
    //---------------------------------------------------------------
    public boolean isDataObject(int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList =  getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();

            if ( tempObject.pointInsideObject(x,y) )
                return true;
        }
        
       return false;
    }
   
    //---------------------------------------------------------------
    // - passes mesage to model and returns result
    //---------------------------------------------------------------
    public EditPanel getEditPanel( dataObject theObject)
    {
       return theModel.getEditPanel(theObject);       
    }

     
      
    //---------------------------------------------------------------
    // - returns first dataObject found with x,y coord
    // - returns null if no object found
    //---------------------------------------------------------------
    public dataObject getDataObject(int x, int y)
    {
        return theModel.getDataObject(x,y);
    }


    //---------------------------------------------------------------
    // USED BY: selectDataObject
    //
    // sets the dragDist(X/Y) variables of all current selected dataObjects
    // relative to the inputted coordinates
    //---------------------------------------------------------------
    private void calculateDragPosition(int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList = getSelectedData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            
            tempObject.dragDistX = tempObject.x - x;
            tempObject.dragDistY = tempObject.y - y;
        }
    }

 
    //---------------------------------------------------------------
    // moves current selected dataObjects to inputted coordinate,
    // relative to dragDist(X/Y)
    //---------------------------------------------------------------
    public void moveSelected( int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList = getSelectedData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            
            tempObject.x = tempObject.dragDistX + x;
            tempObject.y = tempObject.dragDistY + y;
        }
     
    }
    
          
    //---------------------------------------------------------------
    // - Adds the first object found at coordinates (x, y) to the selectedObjVector
    // - If the (x, y) coordinates do not correspond to a dataObject then the
    //   selectedObjVector is cleared 
    //
    // CAVEAT: shiftPressed does not currently work properly
    //---------------------------------------------------------------
    public boolean selectDataObject( int x, int y, boolean shiftPressed )
    {
        dataObject tempObject;
        

        //check all data objects 
        Enumeration dataList = getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
         
            if( tempObject.pointInsideObject(x, y) )
            {
                if( tempObject.objectSelected() )
                {
                    calculateDragPosition(x,y);
                    return true;
                }
                else
                {
                    //deselect other objects if shift not pressed
                    if(!shiftPressed)
                        deSelectObjects();
                
                    tempObject.selectObject();

                    if ( !selectedObjVector.contains(tempObject) )
                        selectedObjVector.addElement(tempObject);
                }

                calculateDragPosition(x,y);
                notifyViews();
                return true;
            }
        }

 
        //User clicked on empty space
        if(!shiftPressed)
            deSelectObjects();
        notifyViews();
        return false;
    }
 
  
  
    
     
    //---------------------------------------------------------------
    //  - Starts a datalink.
    //  - Datalinks contain a pointer and pointee
    //  - This method stores the link as a temporary datalink in the
    //    dataManager and sets the Pointer
    //---------------------------------------------------------------      
    public void startNewLink( int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList =  getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
         
            if( tempObject.pointInsideObject(x, y) )
            {
                tempLink = new dataLink();
                tempLink.setPointer(tempObject);
                creatingNewLink = true;
                return;
            }
        }
   
    }
   
    //---------------------------------------------------------------
    //  - Finishes a datalink.
    //  - Datalinks contain a pointer and pointee
    //  - This method sets the Pointee of our temporarily stored 
    //    datalink and adds the datalink to the appropriate dataObjects
    //---------------------------------------------------------------      
    public boolean finishNewLink( int x, int y)
    {
        dataObject tempObject;
        Enumeration dataList =  getData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
         
            if( tempObject.pointInsideObject(x, y) )
            {
                // Eliminates self-Referential datalinks
                boolean validDataLink = tempLink.setPointee(tempObject);
                
                if( validDataLink )
                {
                    tempLink.getPointer().addPointsToLink( tempLink );
                    tempObject.addPointedFromLink( tempLink );
                    creatingNewLink = false;
                    notifyViews();
                    return true;
                }
                else
                {
                    creatingNewLink = false;
                    return false;
                }
                
            }
        }

        creatingNewLink = false;
        return false;
   
    }


    public boolean creatingNewLink() { return creatingNewLink; }

    //---------------------------------------------------------------  
    //  Clears the selectedObjVector variable
    //---------------------------------------------------------------          
    private void deSelectObjects()
    {
        dataObject tempObject;
        
        //deselect data objects 
        Enumeration dataList = getSelectedData();
        
        while( dataList.hasMoreElements() )
        {
            tempObject = (dataObject)dataList.nextElement();
            tempObject.deSelectObject();
        }


        selectedObjVector.removeAllElements();
    }
      
    public boolean multipleSelectBox( int x, int y, int width, int height, boolean shiftPressed )
    {
        dataObject tempObject;
        boolean retVal = false;
       
        if(!shiftPressed) 
            deSelectObjects();
        
        Enumeration boxList =  getData();
                
        while( boxList.hasMoreElements() )
        {
            tempObject = (dataObject)boxList.nextElement();
         
            if( tempObject.objInsideBox(x, y, width, height) )
            {
                tempObject.selectObject();
                selectedObjVector.addElement(tempObject);
                retVal = true;
             }
        }
   
        return retVal;
    }

    


    public void addDataObject( dataObject newObj)
    {
        dataVector.addElement( newObj );
        notifyViews();
    }

    public void removeDataObject( dataObject toRemove)
    {
        dataVector.removeElement( toRemove );
        selectedObjVector.removeElement( toRemove );
        
        notifyViews();
    }

    public void attach( View observer)
    {
        associatedViews.addElement(observer);
    }
    
    public void detach( View observer)
    {
        associatedViews.removeElement(observer);
    }

    public void notifyViews()
    {
       View someView;
       Enumeration dataList = associatedViews.elements();
        
        while( dataList.hasMoreElements() )
        {
            someView = (View)dataList.nextElement();
            someView.update();
        }
   
    }

    //---------------------------------------------------------------
    // Method calls to the model
    //---------------------------------------------------------------
    public JPopupMenu getDefaultPopup( int x, int y)
    {
        return theModel.getDefaultPopup(x,y);
    }

     public JPopupMenu getDataObjectPopup( int x, int y )
    {
        return theModel.getDataObjectPopup(x,y);
    }
   
    
    
    public void saveData( File outFile)
    {        
        try
        {
            FileOutputStream fos = new FileOutputStream(outFile);
            
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(dataVector);
            
            oos.close();
            fos.close();
            Log.out("File saved");
        }
        catch ( IOException e)
        {
            Log.out(" IOException " + e.getMessage());
        }
    }


    public void loadData( File inFile)
    {        
        try
        {
            FileInputStream fis = new FileInputStream(inFile);
            
            ObjectInputStream ois = new ObjectInputStream(fis);
            
            dataVector.removeAllElements();
            dataVector = (Vector)ois.readObject();
            
            ois.close();
            fis.close();
            
            Log.out("File loaded");
            notifyViews();
        }
        catch ( Exception e)
        {
            Log.out(" IOException " + e.getMessage());
        }
   }


}
