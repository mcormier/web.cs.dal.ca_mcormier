/*
 *  AllusionEditPanel.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Sun Jun 15 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import javax.swing.*;
import javax.swing.event.*;
import java.awt.event.*;
import java.awt.*;

import simple.logging.Log;


public class AllusionEditPanel extends EditPanel
                               implements ActionListener, DocumentListener
{
    private allusionDataObject theData;
    private JDialog	       theDialog;
    
    private GridBagLayout layout;
    private GridBagConstraints c;

    private JTextField titleField;
    private JTextField authorField;
    private JTextField airedField;
    private JTextField epNumField;

    protected static String CANCEL_CHOSEN = "chose_cancel";
    protected static String APPLY_CHOSEN = "chose_apply";

    private boolean dataModified;
      
    public AllusionEditPanel( dataObject data)
    {
        super();
        theData = (allusionDataObject)data;
        
        layout = new GridBagLayout();
        this.setLayout(layout);
        c = new GridBagConstraints();
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(10,5,5,5);  //padding
        c.weightx = 0.5;
        
        _addDataFields();
        dataModified = false;
        _addTextListeners();
        
    }
    
    private void _addTextListeners()
    {
        if( titleField == null) return;
    
        titleField.getDocument().addDocumentListener(this);
        
        if(bookDataObject.isA( theData ) )
            authorField.getDocument().addDocumentListener(this);
        
        if(TelevisionSeries.isA( theData ) )
            airedField.getDocument().addDocumentListener(this);
           
        if(TVEpisode.isA( theData ) )
            epNumField.getDocument().addDocumentListener(this);
      
    }
    
    private void _removeTextListeners()
    {
        titleField.getDocument().removeDocumentListener(this);
        
        if(bookDataObject.isA( theData ) )
            authorField.getDocument().removeDocumentListener(this);

        if(TelevisionSeries.isA( theData ) )
            airedField.getDocument().removeDocumentListener(this);
            
        if(TVEpisode.isA( theData ) )
            epNumField.getDocument().removeDocumentListener(this);
    }
    
    public void attachToDialog( JDialog dialog )
    {
        theDialog = dialog;
        theDialog.getContentPane().add(this);
        theDialog.setSize(200,200);
        
        _removeTextListeners();
        _addButtons();
    }
        
    private void _addDataFields()
    {
        if(movieDataObject.isA( theData ) )
            createMovieForm();
  
        if(bookDataObject.isA( theData ) )
            createBookForm();
            
        if(TelevisionSeries.isA( theData) )
            createTVSeriesForm();
            
        if(TVEpisode.isA( theData ) )
            createTVEpisodeForm();
            
        if(Season.isA( theData) )
            _createSeasonForm();
        
    }

   private void _createSeasonForm()
    {
        Season season = (Season)theData;

        JLabel titleLabel = new JLabel("Title: ");
        
        titleField = new JTextField(season.getTitle());
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        add(titleLabel);

        c.gridx = 2;
        layout.setConstraints(titleField, c);
        add(titleField);
        
    }


    private void createMovieForm()
    {
        movieDataObject movieObject = (movieDataObject)theData;

        JLabel titleLabel = new JLabel("Title: ");
        
        titleField = new JTextField(movieObject.getTitle());
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        add(titleLabel);

        c.gridx = 2;
        layout.setConstraints(titleField, c);
        add(titleField);
        
    }
    
    private void createBookForm()
    {
        bookDataObject bookObject = (bookDataObject)theData;
  
        JLabel titleLabel = new JLabel("Title: ");
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        

        c.weightx = 0.5;
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        add(titleLabel);

        titleField = new JTextField(bookObject.getTitle());
        c.gridx = 2;
        layout.setConstraints(titleField, c);
        add(titleField);
        
     
        JLabel authorLabel = new JLabel("Author: ");
        authorLabel.setHorizontalAlignment(JLabel.RIGHT);
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(authorLabel, c);
        add(authorLabel);

        authorField = new JTextField(bookObject.getAuthor());
        c.gridx = 2;
        layout.setConstraints(authorField, c);
        add(authorField);
              
    }

    private void createTVSeriesForm()
    {
        TelevisionSeries tvSeriesObject = (TelevisionSeries)theData;

        JLabel titleLabel = new JLabel("Title: ");
        
        titleField = new JTextField(tvSeriesObject.getTitle());
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        add(titleLabel);

        c.gridx = 2;
        layout.setConstraints(titleField, c);
        add(titleField);
        
        JLabel timeAiredLabel = new JLabel("Time Aired: ");
        timeAiredLabel.setHorizontalAlignment(JLabel.RIGHT);
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(timeAiredLabel, c);
        add(timeAiredLabel);
      
        airedField = new JTextField(tvSeriesObject.getAirTime() );
        c.gridx = 2;
        layout.setConstraints(airedField, c);
        add(airedField);

    }
    
    private void createTVEpisodeForm()
    {
        TVEpisode episodeObject = (TVEpisode)theData;

        JLabel titleLabel = new JLabel("Title: ");
        
        titleField = new JTextField(episodeObject.getTitle());
        titleLabel.setHorizontalAlignment(JLabel.RIGHT);
        
        c.gridx = 0;
        c.gridy = 0;
        layout.setConstraints(titleLabel, c);
        add(titleLabel);

        c.gridx = 2;
        layout.setConstraints(titleField, c);
        add(titleField);
        
        
        JLabel epNumLabel = new JLabel("Episode Number: ");
        epNumLabel.setHorizontalAlignment(JLabel.RIGHT);
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(epNumLabel, c);
        add(epNumLabel);
      
        epNumField = new JTextField("" + episodeObject.getEpNumber() );

        Dimension d = epNumField.getPreferredSize();
        //MAGIC NUMBER!!!
        d.setSize( 21 * 3, d.getHeight() );
        epNumField.setPreferredSize( d);
        
        c.gridx = 2;
        c.anchor = GridBagConstraints.WEST;
        c.fill   = GridBagConstraints.NONE;
        layout.setConstraints(epNumField, c);
        add(epNumField);
    }

    private void _addButtons()
    {
        JButton cancelButton = new JButton("Cancel");
        JButton applyButton = new JButton("Apply");
        
        c.anchor = GridBagConstraints.SOUTH; //bottom of space
        
        c.weighty = 1.0; 
        c.gridx = 0;
        c.gridy++;
        layout.setConstraints(cancelButton, c);
        
        cancelButton.setActionCommand(CANCEL_CHOSEN);
        cancelButton.addActionListener(this);
        add(cancelButton);
        
        
        c.gridx = 2;
        layout.setConstraints(applyButton, c);
        
        applyButton.setActionCommand(APPLY_CHOSEN);
        applyButton.addActionListener(this);
        add(applyButton);
    }

    
    //Handle action events from all the buttons.
    public void actionPerformed(ActionEvent e) 
    {
        String command = e.getActionCommand();

        if (CANCEL_CHOSEN.equals(command)) 
            cancelChosen();
        
        if (APPLY_CHOSEN.equals(command)) 
            applyChosen();

    }

    private void cancelChosen()
    {
        theDialog.hide();
    }

    private void applyChosen()
    {
        String dataType = theData.isA();
       
        //save data back to data object
        if(movieDataObject.isA( theData ) )
            saveMovieData();
  
        if(bookDataObject.isA( theData ) )
            saveBookData();
        
        if(TelevisionSeries.isA( theData ) )
            saveSeriesData();
       
         if(TVEpisode.isA( theData ) )
            saveEpisodeData();
       
        theDialog.hide();
        dataModified = true;
        
        dataManager.getDataManager().notifyViews();
    }
    
    private void  saveMovieData()
    {
        movieDataObject movieObject = (movieDataObject)theData;
        
        movieObject.setTitle (titleField.getText());
    }
    
    private void saveBookData()
    {
        bookDataObject bookObject = (bookDataObject)theData;
        
        bookObject.setTitle(titleField.getText());
        bookObject.setAuthor(authorField.getText());
    }

    private void saveSeriesData()
    {
        TelevisionSeries tvSeries = (TelevisionSeries)theData;
        
        tvSeries.setTitle (titleField.getText());
    }    
    
    
    private void saveEpisodeData()
    {
        TVEpisode tvEp = (TVEpisode)theData;
        
        tvEp.setTitle (titleField.getText());
        
        _saveTVepNum();

    }    


    public void insertUpdate(DocumentEvent e)
    {
        update(e);
    }

    public void changedUpdate(DocumentEvent e)
    {
        //Log.out("changedUpdate");
    }
    
    public void removeUpdate(DocumentEvent e)
    {
        update(e);
    }


 
    private void _saveTVepNum()
    {
        if(TVEpisode.isA( theData ) )
        {
            TVEpisode episode = (TVEpisode)theData;
            
            int newValue = -1;
            
            try
            {
                Integer fromField = new Integer( epNumField.getText() );
                newValue = fromField.intValue();
            }
            catch (NumberFormatException nfe)
            {
            
            }
            finally
            {
                if( newValue > 0 )
                {
                    episode.setEpNumber( newValue );
                    
                }
            }   
        }
    }
 
 
 
    // FOR LATER....
    // To optimize this method only set the field that changed
    private void update(DocumentEvent e)
    {
    
        theData.setTitle(titleField.getText());
        
        
        if(bookDataObject.isA( theData ) )
        {
            bookDataObject bookObj = (bookDataObject)theData;
            bookObj.setAuthor( authorField.getText() );
        }
        
        if(TelevisionSeries.isA( theData ) )
        {
            TelevisionSeries tvSeries = (TelevisionSeries)theData;
            tvSeries.setAirTime(airedField.getText() );
        }
        
        if(TVEpisode.isA( theData ) )
            _saveTVepNum();

        
        dataManager.getDataManager().notifyViews();
    }
    
}
