/*
 *  movieDataObject.java
 *  allusionsApp
 *
 *  Created by Matthieu Cormier on Wed Apr 30 2003.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import java.io.*;

import org.tigris.gef.util.*;

public class movieDataObject extends allusionDataObject
                           
{
    public static String objectType = "movie";
    
    private String director;
    private int    yearReleased;
    
    public static ImageIcon ICON_IMAGE;

    static 
    {        
        // Load image           
        ICON_IMAGE = ResourceLoader.lookupIconResource(objectType);
    }
  
    public movieDataObject(int X, int Y)
    {
        super();
        x = X;
        y = Y;
        title = new String("Movie");
    }


    public void paintNotSelected(Graphics g)
    {
    
        if ( ICON_IMAGE != null )
        {
            ICON_IMAGE.paintIcon( null, g, x, y);
        }
        else
        {
            g.setColor(new java.awt.Color(0,255,0) );   
            g.fillRect( x, y,width,height);           
        }
 
        
        // Calculate title label position if font size changes or if it 
        // hasn't been calculated before
        if( _savedMetrics == null || _savedMetrics != g.getFontMetrics() )
        {
            _savedMetrics = g.getFontMetrics();
            _calculateTitlePosition();
        }

        // Draw bottom title label
        g.setColor( java.awt.Color.black );     
        g.drawString(title, x + _title_X_RelativePosition,
                            y + _title_Y_RelativePosition);
        
        paintLinks(g);
     }
    
    
 
    
    public String isA() { return movieDataObject.objectType; }
    
    public static boolean isA( dataObject theObject)
    {
        if (theObject == null) return false;
        
        String otherObjectType = theObject.isA();
        
        if( otherObjectType.equals( movieDataObject.objectType ) )
            return true;
            
        return false;
    }
    
}
